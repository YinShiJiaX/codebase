#ifndef __SAL_TYPE__H__
#define __SAL_TYPE__H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef signed char        int8;    /**< 8-bit  signed integer   */
typedef short int          int16;   /**< 16-bit signed integer   */
typedef signed int         int32;   /**< 32-bit signed integer   */
typedef long int           int64;   /**< 64-bit signed integer   */
typedef unsigned char      uint8;   /**< 8-bit  unsigned integer */
typedef unsigned short int uint16;  /**< 16-bit unsigned integer */
typedef unsigned int       uint32;  /**< 32-bit unsigned integer */
typedef unsigned long int  uint64;  /**< 64-bit unsigned integer */
typedef float              float32; /**< 32-bit signed float     */
typedef double             float64; /**< 64-bit signed float     */
#ifndef __cplusplus
typedef int                bool;    /**< Boolean type */
#endif

#undef TRUE
#ifndef TRUE
#define TRUE 1
#endif

#undef FALSE
#ifndef FALSE
#define FALSE 0
#endif

#ifndef NULL
#define NULL 0
#endif

#ifndef INLINE
#ifdef _MSC_VER
#define INLINE __inline
#elif __GNUC__
#define INLINE __inline__
#else
#define INLINE
#endif
#endif

#define STATIC static

#ifdef __cplusplus
}
#endif

#endif /* !__SAL_TYPE__H__ */


