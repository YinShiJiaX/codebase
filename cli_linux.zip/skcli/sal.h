#ifndef __SAL_H__
#define __SAL_H__

#include "sal_types.h"
#include <ctype.h>
#include <stdarg.h>
#include <unistd.h>

#define BOOLEAN_BIT(b) ((b) ? 1 : 0)
#ifndef MIN
#define MIN(a,b) ((a) > (b) ? (b) : (a))
#endif

typedef FILE* sal_file_t;

#undef sal_memcmp
#define sal_memcmp   memcmp

#undef sal_memmove
#define sal_memmove  memmove
/*string*/
#undef sal_vprintf
#define sal_vprintf vprintf

#undef sal_sprintf
#define sal_sprintf sprintf

#undef sal_sscanf
#define sal_sscanf sscanf

#undef sal_strcpy
#define sal_strcpy strcpy

#undef sal_strncpy
#define sal_strncpy strncpy

#undef sal_strcat
#define sal_strcat strcat

#undef sal_strncat
#define sal_strncat strncat

#undef sal_strcmp
#define sal_strcmp strcmp

#undef sal_strncmp
#define sal_strncmp strncmp

#undef sal_strlen
#define sal_strlen strlen

#undef sal_snprintf
#define sal_snprintf snprintf

#undef sal_vsnprintf
#define sal_vsnprintf vsnprintf

#undef sal_vsprintf
#define sal_vsprintf vsprintf

#undef sal_strtos32
#undef sal_strtou32
#undef sal_atoi
#undef sal_strtol
#define sal_atoi atoi
#define sal_strtos32(x, y, z) strtol((char*)x, (char**)y, z)
#define sal_strtou32(x, y, z) strtoul((char*)x, (char**)y, z)
#define sal_strtol strtol

#undef sal_rand
#define sal_rand rand

#undef sal_srand
#define sal_srand srand

/*memory */
#undef sal_malloc
#define sal_malloc   malloc

#undef sal_realloc
#define sal_realloc realloc

#undef sal_free
#define sal_free   free

#undef  sal_strtou64
#define sal_strtou64(x, y, z) strtoull((char*)x, (char**)y, z)

#undef sal_strchr
#define sal_strchr strchr

#undef sal_strspn
#define sal_strspn strspn

#undef sal_tolower
#undef sal_toupper
#define sal_tolower tolower
#define sal_toupper toupper

#undef sal_isspace
#undef sal_isdigit
#undef sal_isxdigit
#undef sal_isalpha
#undef sal_isalnum
#undef sal_isupper
#undef sal_islower
#define sal_isspace isspace
#define sal_isdigit isdigit
#define sal_isxdigit isxdigit
#define sal_isalpha isalpha
#define sal_isalnum isalnum
#define sal_isupper isupper
#define sal_islower islower
#define sal_isprint isprint

#undef sal_ntohl
#undef sal_htonl
#undef sal_ntohs
#undef sal_htons
#define sal_htons(x) ((u16_t)((((x) & (u16_t)0x00ffU) << 8) | (((x) & (u16_t)0xff00U) >> 8)))
#define sal_ntohs(x) sal_htons(x)
#define sal_htonl(x) ((((x) & (u32_t)0x000000ffUL) << 24) | \
                     (((x) & (u32_t)0x0000ff00UL) <<  8) | \
                     (((x) & (u32_t)0x00ff0000UL) >>  8) | \
                     (((x) & (u32_t)0xff000000UL) >> 24))
#define sal_ntohl(x) sal_htonl(x)


#define sal_printf  printf

#undef sal_memcpy
#undef sal_memset
#define sal_memcpy    memcpy
#define sal_memset    memset

#undef sal_qsort
#define sal_qsort qsort

#define SET_BIT(flag, bit)      (flag) = (flag) | (1 << (bit))
#define CLEAR_BIT(flag, bit)    (flag) = (flag) & (~(1 << (bit)))
#define IS_BIT_SET(flag, bit)   (((flag) & (1 << (bit))) ? 1 : 0)

#define SET_BIT_RANGE(dst, src, s_bit, len) \
    { \
        uint8 i = 0; \
        for (i = 0; i < len; i++) \
        { \
            if (IS_BIT_SET(src, i)) \
            { \
                SET_BIT(dst, (s_bit + i)); \
            } \
            else \
            { \
                CLEAR_BIT(dst, (s_bit + i)); \
            } \
        } \
    }

#define mem_malloc(type, size)  (size == 0 ? NULL : sal_malloc(size))
#define mem_free(ptr)   \
    { \
        if(ptr) sal_free(ptr); \
        ptr = NULL;/*must set to NULL*/ \
    }
#define mem_realloc(type, ptr, size) sal_realloc(ptr, size)

#ifdef __cplusplus
extern "C" {
#endif

#undef sal_read
#define sal_read read

#undef sal_write
#define sal_write write

#ifdef __cplusplus
}
#endif

#endif /* !__SAL_H__ */


