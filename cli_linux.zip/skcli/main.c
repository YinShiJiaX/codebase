#include "ctc_cli.h"
#include "ctc_cmd.h"

CTC_CLI(xx_sci,
        xx_sci_cmd,
        "ls",
        "you got it")
{
    printf("yes hahaha\n");
    return CLI_SUCCESS;
}

#define EXEC_MODE 0
ctc_cmd_node_t exec_node =
{
    EXEC_MODE,
    "\rCTC_CLI# ",
};

int ctc_master_printf(struct ctc_vti_struct_s* vti, const char *szPtr, const int szPtr_len)
{
    sal_write(0,(void*)szPtr,szPtr_len);
    return 0;
}

uint8 cli_end;
int main(int argc, char **argv)
{
    uint32  nbytes = 0;
    int8*   pread_buf = NULL;
    cli_end = 0;

    ctc_cmd_init(0);

    ctc_install_node(&exec_node, NULL);

    install_element(EXEC_MODE, &xx_sci_cmd);

    ctc_vti_init(EXEC_MODE);

    ctc_sort_node();

    pread_buf = sal_malloc(CTC_VTI_BUFSIZ);

    if (NULL == pread_buf)
    {
        return - 1;
    }

    set_terminal_raw_mode(CTC_VTI_SHELL_MODE_DEFAULT);

    g_ctc_vti->printf = ctc_master_printf;

    while (cli_end == 0)
    {
        nbytes = ctc_vti_read(pread_buf, CTC_VTI_BUFSIZ, CTC_VTI_SHELL_MODE_DEFAULT);
        ctc_vti_cmd_input(pread_buf, nbytes);
    }

    restore_terminal_mode(CTC_VTI_SHELL_MODE_DEFAULT);
    sal_free(pread_buf);

    return 0;
}
