#ifndef REGEX_H
#define REGEX_H

#include "sal.h"

extern char *ctc_regex_complete(char *);
extern int32 ctc_regex_exec(char *);

#endif /* REGEX_H */
