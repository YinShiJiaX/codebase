/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_vlan.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-04-12 
  
  Description   : vlan相关CLI源文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-4-12    1.0.0000     初次建立
*************************************************************************************/
#include "sciyon_cli_vlan.h"
#include "sciyon_app.h"
#include "sciyon_cli.h"
#include "common/include/ctc_const.h"
#include "sciyon_save_cfg.h"
#include "sciyon_l3.h"
#include "sciyon_phy.h"

extern sciyon_phy_info_t sciyon_g_phy_port_info[KN831H_PHY_NUM];
extern sciyon_vlanif_t sciyon_g_vlanif_pool[SCIYON_VLANIF_MAX_NUM];
extern uint8 sciyon_g_vlanif_num;
extern sciyon_mac_addr_t sciyon_g_router_mac;

CTC_CLI(sciyon_cli_vlan_vlan_view_config,
        sciyon_cli_vlan_vlan_view_cmd,
        "vlan VLAN_ID",
        VLAN_MODULE_STR,
        "vlan id<10-35>")
{
    uint16 vlan_id = 0;
    char str[SCIYON_MAX_PROMPT_LEN];
    bool vlan_create = 0;
    ctc_vlan_uservlan_t user_vlan;

    CTC_CLI_GET_UINT16("vlan id", vlan_id, argv[0]);

    if( (vlan_id > SCIYON_MAX_VLAN_ID) || (vlan_id < SCIYON_MIN_VLAN_ID))
    {
        ctc_cli_out("error: vlan id invalid\n");
        return CLI_ERROR;
    }

    sciyon_g_current_vlan_id = vlan_id;

    /* 检查vlan是否创建 */
    ctc_vlan_get_receive_en(vlan_id, &vlan_create);
    if(!vlan_create)
    {
        /* 创建新的vlan */
        sal_memset(&user_vlan, 0, sizeof(ctc_vlan_uservlan_t));
        user_vlan.vlan_id = vlan_id;
        user_vlan.user_vlanptr = vlan_id;
        user_vlan.fid = vlan_id;
        ctc_vlan_create_uservlan(&user_vlan);
    }
    
    /* 视图切换 */
    sal_sprintf(str, "\r[SCIYON-Vlan%d] ", vlan_id);
    sal_strcpy(vlan_node.prompt, str);
    g_ctc_vti->node = SCIYON_VLAN_MODE;
    return CLI_SUCCESS;
}


CTC_CLI(sciyon_cli_vlan_l3if_info_config,
        sciyon_cli_vlan_l3if_info_cmd,
        "display l3if",
        "display",
        "l3if")
{
    int i;
    char l3ifstr[20];

    ctc_cli_out("vlan ID    IP                  NETMASK    MAC\n");
    ctc_cli_out("-------------------------------------------------------\n");
    for(i = 0; i < sciyon_g_vlanif_num; i++)
    {
        sal_sprintf(l3ifstr, "%d", sciyon_g_vlanif_pool[i].vlan_id);
        ctc_cli_out("%-11s", l3ifstr);
        sal_sprintf(l3ifstr, "%d.%d.%d.%d", 
                    sciyon_g_vlanif_pool[i].ip[0], sciyon_g_vlanif_pool[i].ip[1], 
                    sciyon_g_vlanif_pool[i].ip[2], sciyon_g_vlanif_pool[i].ip[3]);
        ctc_cli_out("%-20s", l3ifstr);
        sal_sprintf(l3ifstr, "%d", sciyon_g_vlanif_pool[i].netmask);
        ctc_cli_out("%-11s", l3ifstr);
        sal_sprintf(l3ifstr, "%.2x%.2x.%.2x%.2x.%.2x%.2x\n", 
                    sciyon_g_vlanif_pool[i].mac[0], sciyon_g_vlanif_pool[i].mac[1],
                    sciyon_g_vlanif_pool[i].mac[2], sciyon_g_vlanif_pool[i].mac[3],
                    sciyon_g_vlanif_pool[i].mac[4], sciyon_g_vlanif_pool[i].mac[5]);
        ctc_cli_out("%-14s", l3ifstr);
    }
    ctc_cli_out("-------------------------------------------------------\n");
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_vlan_display_vlan_config,
        sciyon_cli_vlan_display_vlan_cmd,
        "display vlan",
        "display",
        "vlan")
{
    bool vlan_create = 0;
    uint16 default_vlan = 0;
    uint16 i, j, k;/* k 用于打印对齐 */
    char vlanstr[10];

    ctc_cli_out("VLAN      Ports\n");
    ctc_cli_out("----------------------------------------------------------\n");
    for(i = 1; i <= SCIYON_MAX_VLAN_ID; i++)
    {
        vlan_create = 0;
        k = 0;
        ctc_vlan_get_receive_en(i, &vlan_create);
        if(!vlan_create) continue;
        sal_sprintf(vlanstr, "%d", i);
        sal_strncat(vlanstr, "                ", 10 - strlen(vlanstr) );
        ctc_cli_out("%s", vlanstr);
        for(j = 0; j < KN831H_PHY_NUM; j++)
        {
            ctc_port_get_default_vlan(sciyon_g_phy_port_info[j].gport, &default_vlan);
            if(i == default_vlan) 
            {
                ctc_cli_out("GE%d  ", j + 1);
                k++;
                if( (k) && (!(k%4)) ) ctc_cli_out("\n          ");/* 4个端口一次换行 */
            }
        }
        ctc_cli_out("\n");
    }
    ctc_cli_out("----------------------------------------------------------\n");
    
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_vlan_display_vlan_vlanid_config,
        sciyon_cli_vlan_display_vlan_vlanid_cmd,
        "display vlan VLAN_ID",
        "display",
        "vlan",
        "vlan id")
{
    bool vlan_create = 0;
    int i, k=0;
    uint16 vlan_id;
    uint16 default_vlan;
    char vlanstr[10];

    CTC_CLI_GET_UINT16("vlan id", vlan_id, argv[0]);

    ctc_vlan_get_receive_en(vlan_id, &vlan_create);
    if(!vlan_create)
    {
        ctc_cli_out("error: vlan doesn't exist\n");
        return CLI_ERROR;
    }

    ctc_cli_out("VLAN      Ports\n");
    ctc_cli_out("----------------------------------------------------------\n");
    sal_sprintf(vlanstr, "%d", vlan_id);
    sal_strncat(vlanstr, "                ", 10 - strlen(vlanstr) );
    ctc_cli_out("%s", vlanstr);
    for(i = 0; i < KN831H_PHY_NUM; i++)
    {
        ctc_port_get_default_vlan(sciyon_g_phy_port_info[i].gport, &default_vlan);
        if(vlan_id == default_vlan) 
        {
            ctc_cli_out("GE%d  ", i + 1);
            k++;
            if( (k) && (!(k%4)) ) ctc_cli_out("\n          ");/* 4个端口一次换行 */
        }
    }
    ctc_cli_out("\n----------------------------------------------------------\n");
    ctc_cli_out("ports num: %d\n", k);
    
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_vlan_l3if_create_config,
        sciyon_cli_vlan_l3if_create_cmd,
        "ip address IP NETMASK",
        "ip",
        "address",
        "IP ADDR",
        "NET MASK")
{
    uint32 ip;
    int32 ret = 0;
    uint32 i;
    uint8 netmask;
    ctc_exception_type_t type;
    ctc_l3if_t  l3if;
    ctc_l3if_router_mac_t rtmac;
    uint16 l3if_id = 0;

    if(sciyon_g_vlanif_num >= SCIYON_VLANIF_MAX_NUM)
    {
        sal_printf("error: vlanif num is no more than %d\n", SCIYON_VLANIF_MAX_NUM);
        return CLI_ERROR;
    }

    CTC_CLI_GET_IPV4_ADDRESS("ip address", ip, argv[0]);
    CTC_CLI_GET_UINT8("netmask", netmask, argv[1]);

    /* 如果当前VLAN已经设置了三层接口，那么只更新其对应的IP */
    for(i = 0; i < sciyon_g_vlanif_num; i++)
    {
        if(sciyon_g_current_vlan_id == sciyon_g_vlanif_pool[i].vlan_id)
        {
            sciyon_g_vlanif_pool[i].ip[0]  = ((uint8 *)&ip)[3];
            sciyon_g_vlanif_pool[i].ip[1]  = ((uint8 *)&ip)[2];
            sciyon_g_vlanif_pool[i].ip[2]  = ((uint8 *)&ip)[1];
            sciyon_g_vlanif_pool[i].ip[3]  = ((uint8 *)&ip)[0];
            sciyon_g_vlanif_pool[i].netmask = netmask;
            return CLI_SUCCESS;
        }
    }

    /* l3if config */
    sal_memset(&l3if, 0, sizeof(ctc_l3if_t));
    l3if_id = sciyon_g_current_vlan_id;	/* 三层接口ID就设置为vlan_id */
    l3if.l3if_type = CTC_L3IF_TYPE_VLAN_IF;
    l3if.vlan_id = sciyon_g_current_vlan_id;
    ctc_l3if_create (l3if_id, &l3if);

    sciyon_g_vlanif_pool[sciyon_g_vlanif_num].vlan_id = sciyon_g_current_vlan_id;
    sciyon_g_vlanif_pool[sciyon_g_vlanif_num].ip[0]  = ((uint8 *)&ip)[3];
    sciyon_g_vlanif_pool[sciyon_g_vlanif_num].ip[1]  = ((uint8 *)&ip)[2];
    sciyon_g_vlanif_pool[sciyon_g_vlanif_num].ip[2]  = ((uint8 *)&ip)[1];
    sciyon_g_vlanif_pool[sciyon_g_vlanif_num].ip[3]  = ((uint8 *)&ip)[0];
    sciyon_g_vlanif_pool[sciyon_g_vlanif_num].netmask = netmask;

    /* 设置vlanif mac */
    sal_memcpy(sciyon_g_vlanif_pool[sciyon_g_vlanif_num].mac, sciyon_g_router_mac, SCIYON_MAC_ADDR_LEN);
    sciyon_g_vlanif_pool[sciyon_g_vlanif_num].mac[5] = sciyon_g_current_vlan_id;
    sal_memcpy(rtmac.mac, sciyon_g_vlanif_pool[sciyon_g_vlanif_num].mac, 6);
    rtmac.num = 1;
    ret = ctc_l3if_set_interface_router_mac(l3if_id, rtmac);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    /* 设置ARP报文行为：copy给cpu */
    type = CTC_EXCP_FWD_AND_TO_CPU;
    ctc_vlan_set_arp_excp_type(sciyon_g_current_vlan_id, type);
    
    sciyon_g_vlanif_num++;

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_vlan_undo_l3if_create_config,
        sciyon_cli_vlan_undo_l3if_create_cmd,
        "undo ip address IP NETMASK",
        "undo",
        "ip",
        "address",
        "IP ADDR",
        "NET MASK")
{
    uint32 ip;
    uint32 i;
    uint8 netmask;
    ctc_exception_type_t type;
    ctc_l3if_t  l3if;
    uint16 l3if_id = 0;
    uint8 found = 0;

    if(sciyon_g_vlanif_num <= 0)
    {
        ctc_cli_out("l3if num is zero!\n");
        return CLI_ERROR;
    }

    CTC_CLI_GET_IPV4_ADDRESS("ip address", ip, argv[0]);
    CTC_CLI_GET_UINT8("netmask", netmask, argv[1]);

    /* 如果当前VLAN已经设置了三层接口，那么只更新其对应的IP */
    for(i = 0; i < sciyon_g_vlanif_num; i++)
    {
        if( (sciyon_g_vlanif_pool[i].vlan_id == sciyon_g_current_vlan_id)   &&
            (sciyon_g_vlanif_pool[i].ip[0]  == ((uint8 *)&ip)[3])           &&
            (sciyon_g_vlanif_pool[i].ip[1]  == ((uint8 *)&ip)[2])           &&
            (sciyon_g_vlanif_pool[i].ip[2]  == ((uint8 *)&ip)[1])           &&
            (sciyon_g_vlanif_pool[i].ip[3]  == ((uint8 *)&ip)[0])           &&
            (sciyon_g_vlanif_pool[i].netmask == netmask))
        {
            found = 1;
        }

        if(found)
        {
            sciyon_g_vlanif_pool[i].vlan_id = sciyon_g_vlanif_pool[i+1].vlan_id;
            sciyon_g_vlanif_pool[i].ip[0]  = sciyon_g_vlanif_pool[i+1].ip[0];
            sciyon_g_vlanif_pool[i].ip[1]  = sciyon_g_vlanif_pool[i+1].ip[1];
            sciyon_g_vlanif_pool[i].ip[2]  = sciyon_g_vlanif_pool[i+1].ip[2];
            sciyon_g_vlanif_pool[i].ip[3]  = sciyon_g_vlanif_pool[i+1].ip[3];
            sciyon_g_vlanif_pool[i].netmask = netmask;
        }
    }

    if(found)
    {
        /* 删除三层接口 */
        sal_memset(&l3if, 0, sizeof(ctc_l3if_t));
        l3if_id = sciyon_g_current_vlan_id;	/* 三层接口ID就设置为vlan_id */
        l3if.l3if_type = CTC_L3IF_TYPE_VLAN_IF;
        l3if.vlan_id = sciyon_g_current_vlan_id;
        ctc_l3if_destory (l3if_id, &l3if);

        /* 设置ARP报文行为 */
        type = CTC_EXCP_NORMAL_FWD;
        ctc_vlan_set_arp_excp_type(sciyon_g_current_vlan_id, type);
        sciyon_g_vlanif_num--;
        return CLI_SUCCESS;
    }

    ctc_cli_out("l3 interface not exist\n");

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_vlan_undo_config,
        sciyon_cli_vlan_undo_cmd,
        "undo vlan VLAN_ID",
        UNDO_MODULE_STR,
        "vlan",
        "VLAN_ID")
{
    uint16 ret;
    uint16 vlan_id = 0;
    bool vlan_create = 0;

    CTC_CLI_GET_UINT16("vlan id", vlan_id, argv[0]);

    if( (vlan_id > SCIYON_MAX_VLAN_ID) || (vlan_id < SCIYON_MIN_VLAN_ID))
    {
        ctc_cli_out("vlan id invalid\n");
        return CLI_ERROR;
    }

    /* 检查vlan是否创建 */
    ctc_vlan_get_receive_en(vlan_id, &vlan_create);

    if(vlan_create)
    {
        ret = ctc_vlan_destroy_vlan(vlan_id);
        if(CTC_E_NONE != ret)
        {
            ctc_cli_out("vlan remove fail\n");
            return ret;
        }
        return CLI_SUCCESS;
    }

    ctc_cli_out("vlan not exist\n");

    return CLI_SUCCESS;
}


int32 sciyon_cli_vlan_init(void)
{
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_vlan_undo_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_vlan_vlan_view_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_vlan_l3if_info_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_vlan_display_vlan_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_vlan_display_vlan_vlanid_cmd);

    install_element(SCIYON_VLAN_MODE, &sciyon_cli_vlan_l3if_create_cmd);
    install_element(SCIYON_VLAN_MODE, &sciyon_cli_vlan_vlan_view_cmd);
    install_element(SCIYON_VLAN_MODE, &sciyon_cli_vlan_undo_l3if_create_cmd);

    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_vlan_vlan_view_cmd);
    
    return CLI_SUCCESS;
}