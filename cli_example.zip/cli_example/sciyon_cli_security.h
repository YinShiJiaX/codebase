/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_security.h
  Author: yinsj             Version: 1.0.0000          Data: 2021-05-28
  
  Description   : security相关CLI的头文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-5-28    1.0.0000     初次建立
*************************************************************************************/
#ifndef _SCIYON_CLI_SECURITY_H
#define _SCIYON_CLI_SECURITY_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sal_types.h"

int32 sciyon_cli_security_init(void);

#ifdef __cplusplus
}
#endif

#endif /* _SCIYON_CLI_SECURITY_H */