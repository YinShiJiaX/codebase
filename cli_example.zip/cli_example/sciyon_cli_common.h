/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_common.h
  Author: yinsj             Version: 1.0.0000          Data: 2021-04-07 
  
  Description   : 通用CLI的头文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-4-7    1.0.0000     初次建立
*************************************************************************************/
#ifndef _SCIYON_CLI_COMMON_H
#define _SCIYON_CLI_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sal_types.h"

#define CMD_MAX_LEN      150             /* 一个命令的最大长度 */
#define CMD_MAX_NUM      1000            /* 一个配置文件最多支持1000行 */
#define CONSOLE_PATH     "/dev/ttyAMA0"

#define SCIYON_KN831H_EXIT_PASSWD      "12345678"
#define SCIYON_KN831H_LOGIN_PASSWD     "12345678"
#define SCIYON_KN831H_LOGIN_BACK       "002380" /* 备份密码，用于防止用户忘记密码 */
#define SCIYON_KN831H_USER_NAME        "admin"

int32 sciyon_cli_common_init(void);

#ifdef __cplusplus
}
#endif

#endif /* _SCIYON_CLI_COMMON_H */