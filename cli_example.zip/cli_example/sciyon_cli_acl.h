/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_acl.h
  Author: yinsj             Version: 1.0.0000          Data: 2021-05-13 
  
  Description   : ACL
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-5-13    1.0.0000     初次建立
*************************************************************************************/

#ifndef _SCIYON_CLI_ACL_H
#define _SCIYON_CLI_ACL_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sal_types.h"
#include "sciyon_l3.h"

#define SCIYON_MAX_ACL_NUMBER     23
#define SCIYON_MIN_ACL_NUMBER     0
#define SCIYON_MAX_ACL_COUNT      24
#define SCIYON_ACE_NUM_PER_PORT   48

struct sciyon_acl_rule_info_s {
    uint32 rule_id;
    sciyon_ip_addr_t ip;
    sciyon_ip_addr_t netmask;
};
typedef struct sciyon_acl_rule_info_s sciyon_acl_t;

int32 sciyon_cli_acl_init(void);

#ifdef __cplusplus
}
#endif

#endif /* _SCIYON_CLI_ACL_H */