/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_ipmc.h
  Author: yinsj             Version: 1.0.0000          Data: 2021-05-12
  
  Description   : IPMC
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-5-12    1.0.0000     初次建立
*************************************************************************************/
#ifndef _SCIYON_CLI_IPMC_H
#define _SCIYON_CLI_IPMC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sal_types.h"

int32 sciyon_cli_ipmc_init(void);

#ifdef __cplusplus
}
#endif

#endif /* _SCIYON_CLI_IPMC_H */