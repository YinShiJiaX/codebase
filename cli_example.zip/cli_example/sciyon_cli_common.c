/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_common.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-04-07 
  
  Description   : 通用CLI的源文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-4-7    1.0.0000     初次建立
*************************************************************************************/
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sciyon_cli_common.h"
#include "sciyon_cli.h"
#include "sal.h"
#include "api/include/ctc_api.h"
#include "ctc_cli_common.h"
#include "ctc_common_cli.h"
#include "ctc_app.h"
#include "ctc_cli.h"
#include "common/include/ctc_chip.h"
#include "sciyon_app.h"
#include "sciyon_common.h"
#include "sciyon_save_cfg.h"
#include "sciyon_phy.h"
#include "sciyon_ipuc.h"
#include "sciyon_ipmc.h"
#include "sciyon_cli_acl.h"
#include "sciyon_cli_vlan.h"
#include "sciyon_l3.h"
#include "sciyon_version.h"

extern void sys_usw_mac_stats_get_port_rate(uint8 lchip, uint32 gport, uint64* p_rate);
extern void ctc_vti_clear_buf(ctc_vti_t* vti);
extern void sciyon_main_exit_clear(void);
extern void sciyon_vlanif_collections_clear(void);
extern void sciyon_soft_ipuc_pool_clear(void);
extern void sciyon_soft_ipmc_pool_clear(void);
extern void sciyon_soft_acl_pool_clear(void);

extern ctc_vti_t* g_ctc_vti;
extern uint8 cli_end;
extern uint8 sciyon_g_soft_reset;
extern sciyon_phy_info_t sciyon_g_phy_port_info[KN831H_PHY_NUM];
extern struct timeval sciyon_g_time_start;
extern char sciyon_g_passwd[SCIYON_PASSWD_LEN];
extern char sciyon_passwd_input[SCIYON_PASSWD_INPUT_LEN];
extern uint8 sciyon_current_passwd_index;

CTC_CLI(sciyon_cli_common_display_resource_config,
        sciyon_cli_common_display_resource_cmd,
        "display resource",
        "display",
        "resource")
{
    ctc_cli_out("resource:\n");
    ctc_cli_out("ipuc max num: %d\n", SCIYON_IPUC_MAX_NUM);
    ctc_cli_out("ipmc max num: %d\n", SCIYON_IPMC_MAX_NUM);
    ctc_cli_out("acl  max num: %d\n", SCIYON_MAX_ACL_COUNT);
    ctc_cli_out("vlan max num: %d\n", SCIYON_VLAN_MAX_NUM);
    ctc_cli_out("vlanif max num: %d\n", SCIYON_VLANIF_MAX_NUM);

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_display_time_passed_config,
        sciyon_cli_common_display_time_passed_cmd,
        "display time-passed",
        "display",
        "time passed")
{
    uint32 days = 0;
    uint32 hours = 0;
    uint32 minutes = 0;
    uint32 seconds = 0;
    long long temp = 0;
    struct timeval time_now;
    
    memset(&time_now, 0, sizeof(struct timeval));
    gettimeofday(&time_now, 0);
    temp = time_now.tv_sec - sciyon_g_time_start.tv_sec;

    if( temp >= (3600 * 24) )
    {
        days = temp / (3600 * 24);
        temp = temp % (3600 * 24);
        hours = temp / 3600;
        temp = temp % 3600;
        minutes = temp / 60;
        temp = temp % 60;
        seconds = temp;
        ctc_cli_out("time passed: %dd:%dh:%dm:%ds\n", days, hours, minutes, seconds);
        return CLI_SUCCESS;
    }

    if( temp >= 3600 )
    {
        hours = temp / 3600;
        temp = temp % 3600;
        minutes = temp / 60;
        temp = temp % 60;
        seconds = temp;
        ctc_cli_out("time passed: %dh:%dm:%ds\n", hours, minutes, seconds);
        return CLI_SUCCESS;
    }

    if( temp >= 60 )
    {
        minutes = temp / 60;
        temp = temp % 60;
        seconds = temp;
        ctc_cli_out("time passed: %dm:%ds\n", minutes, seconds);
        return CLI_SUCCESS;
    }

    if( temp > 0 )
    {
        seconds = temp;
        ctc_cli_out("time passed: %ds\n", seconds);
    }

    return CLI_SUCCESS;
}

void sciyon_cli_mode_exit(void)
{
    switch (g_ctc_vti->node)
    {
        case SCIYON_INTERFACE_MODE:
            g_ctc_vti->node = SCIYON_SYSTEM_MODE;
            break;
        case SCIYON_SYSTEM_MODE:
            g_ctc_vti->node = SCIYON_USER_MODE;
            break;
        case SCIYON_VLAN_MODE:
            g_ctc_vti->node = SCIYON_SYSTEM_MODE;
            break;
        default:
            /* 退出SDK前，进行一些必要的清理工作 */
            sciyon_main_exit_clear();
            sciyon_ipuc_exit_clear();
            sciyon_ipmc_exit_clear();
            g_ctc_vti->quit(g_ctc_vti);
            break;
    }
}

/* Cmd format: cd <path> */
CTC_CLI(sciyon_cli_common_change_dir_config,
        sciyon_cli_common_change_dir_cmd,
        "cd FILE_PATH",
        "Common cmd",
        "File path")
{
    int32 i;
    char path[256] = {0};
    char* work_dir = NULL;

    sal_memset(path, 0, 256);

    work_dir = argv[0];

    /*ingore one dot*/
    if (0 == sal_strcmp(work_dir, "."))
    {
        return CLI_ERROR;
    }

    /*switch to parent directory*/
    if (0 == sal_strcmp(work_dir, ".."))
    {
        if (getcwd(path, 256) == NULL)
        {
            ctc_cli_out("%% Get current work directory failed!\n");
            return CLI_ERROR;
        }

        i = sal_strlen(path);

        while (i)
        {
            if ('/' == path[i])
            {
                break;
            }
            else
            {
                path[i] = 0;
            }

            --i;
        }

        chdir(path);
    }
    else /*enter subdirectory*/
    {
        int32 ret;
        if (getcwd(path, 256) == NULL)
        {
            ctc_cli_out("%% Get current work directory failed!\n");
            return CLI_ERROR;
        }

        i = sal_strlen(path);
        path[i] = '/';
        sal_strcat(path, work_dir);
        chdir(path);

        ret = chdir(path);
        if (ret == -1)
        {
            sal_memset(path, 0, sizeof(path));
            sal_memcpy(path, work_dir, sizeof(path));
            ret = chdir(path);
            if (ret == -1)
            {
                ctc_cli_out("%% Invalid path: %s!\n", path);
                return CLI_ERROR;
            }
        }
    }

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_display_history_config,
        sciyon_cli_common_display_history_cmd,
        "display history",
        "display",
        "Display the session command history")
{
    int index;
    int print_index = 1;

    for (index = g_ctc_vti->hindex + 1; index != g_ctc_vti->hindex;)
    {
        if (index == CTC_VTI_MAXHIST)
        {
            index = 0;
            continue;
        }

        if (g_ctc_vti->hist[index] != NULL)
        {
            ctc_cli_out("%d  %s%s", print_index, g_ctc_vti->hist[index], CTC_VTI_NEWLINE);
            print_index++;
        }

        index++;
    }

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_vi_config,
        sciyon_cli_common_vi_cmd,
        "vi FILE_PATH",
        "Common cmd",
        "fFile path")
{
    char* filename = NULL;
    char command[256] = {0};

    sal_memset(command, 0, 256);

    filename = argv[0];

    sal_strcat(command, "vi ");
    sal_strcat(command, filename);
    system(command);

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_soft_reset_config,
        sciyon_cli_common_soft_reset_cmd,
        "soft reset",
        "soft",
        "reset")
{
    FILE *fp=NULL;
    char cmd;

    /*===============软启动前的确认==============*/
    fp = sal_fopen(CONSOLE_PATH, "r");
    if(NULL == fp)
    {
        ctc_cli_out("console file open failed\n");
        return CLI_SUCCESS;
    }

    while(1)
    {
        ctc_cli_out("do you really want to soft reset?(Y/N)");
        fread(&cmd, 1, 1, fp);
        ctc_cli_out("%c\n", cmd);
        if( ('N' == cmd) || 
            ('n' == cmd) )
        {
            sal_fclose(fp);
            return CLI_SUCCESS;
        }
        else if( ('Y' == cmd) || 
                 ('y' == cmd) )
        {
            sal_fclose(fp);
            break;
        }
        else
        {
            continue;
        }
    }
    
    /* 进行软复位前，进行一些必要的清理工作 */
    sciyon_main_exit_clear();
    sciyon_ipuc_exit_clear();
    sciyon_ipmc_exit_clear();

    /* 清空所有软表 */
    sciyon_vlanif_collections_clear();
    sciyon_soft_ipuc_pool_clear();
    sciyon_soft_ipmc_pool_clear();
    sciyon_soft_acl_pool_clear();

    cli_end = 1;
    sciyon_g_soft_reset = 1;
    ctc_sdk_deinit();

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_show_file_dir_config,
        sciyon_cli_common_show_file_dir_cmd,
        "pwd",
        "Common cmd")
{

    char path[256] = {0};

    sal_memset(path, 0, 256);
    if (getcwd(path, 256) == NULL)
    {
        ctc_cli_out("%% Show current work directory failed!\n");
        return CLI_ERROR;
    }
    else
    {
        ctc_cli_out("%s\n", path);
    }

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_diff_config,
        sciyon_cli_common_diff_cmd,
        "diff FILE1 FILE2",
        "Common cmd",
        "file1",
        "file2")
{
    char* filename1 = NULL;
    char* filename2 =NULL;
    char command[256] = {0};

    sal_memset(command, 0, 256);

    filename1 = argv[0];
    filename2 = argv[1];

    sal_strcat(command, "diff ");
    sal_strcat(command, filename1);
    sal_strcat(command, " ");
    sal_strcat(command, filename2);
    system(command);

    return CLI_SUCCESS;

}

CTC_CLI(sciyon_script,
        sciyon_cli_common_save_cfg_cmd,
        "save config",
        SAVE_MODULE_STR,
        "config")
{
    FILE *fp=NULL;
    char cmd;

    /*===============保存配置前的确认==============*/
    fp = sal_fopen(CONSOLE_PATH, "r");
    if(NULL == fp)
    {
        ctc_cli_out("console file open failed\n");
        return CLI_SUCCESS;
    }

    while(1)
    {
        ctc_cli_out("do you really want to save config?(Y/N)");
        fread(&cmd, 1, 1, fp);
        ctc_cli_out("%c\n", cmd);
        if( ('N' == cmd) || 
            ('n' == cmd) )
        {
            sal_fclose(fp);
            return CLI_SUCCESS;
        }
        else if( ('Y' == cmd) || 
                 ('y' == cmd) )
        {
            sal_fclose(fp);
            break;
        }
        else
        {
            continue;
        }
    }

    ctc_cli_out("saving......done\n");
    char *user_cfg = "user.cfg";

    sciyon_save_user_cfg(user_cfg);

    return CLI_SUCCESS;
}

/* Cmd format: execute <file_name> */
CTC_CLI(sciyon_cli_common_execute_file,
        sciyon_cli_common_execute_file_cmd,
        "execute INPUT_FILE",
        "Common cmd",
        "Input file path")
{
    FILE *fp;
    int i, j;
    char command[CMD_MAX_NUM][CMD_MAX_LEN] = {0};
    char str[CMD_MAX_LEN]={0};
    char *filename;

    filename = argv[0];

    memset((char*)command, 0, CMD_MAX_NUM * CMD_MAX_LEN);
    memset(str, 0, sizeof(char) * CMD_MAX_LEN );

    ctc_vti_clear_buf(g_ctc_vti); /* 清空缓冲区 */
    ctc_vti_cmd_input((int8 *)("\n"), 1);/* 先打个回车，否则脚本会执行异常 */

    if( NULL == (fp=fopen(filename,"r")) )
    {
        ctc_cli_out("%s\n", filename);
        return CLI_ERROR;
    }

    i = 0;
    while(fgets(str, CMD_MAX_LEN, fp) != NULL){
        if(!sal_strcmp(str, "#\n"))/* 跳过分隔符 */
        {
            continue;
        }
        strcpy(command[i++], str);
    }

    for(j = 0; j < i; j++)
    {
        ctc_vti_cmd_input((int8 *)command[j], strlen(command[j]));
    }
    fclose(fp);

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_return_config,
        sciyon_cli_common_return_cmd,
        "return",
        "return")
{
    g_ctc_vti->node = SCIYON_USER_MODE;

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_quit_config,
        sciyon_cli_common_quit_cmd,
        "quit PASSWD",
        "exit sdk")
{
    char *filename;

    filename = argv[0];

    if( !sal_strcmp(filename, SCIYON_KN831H_EXIT_PASSWD) )
    {
        sciyon_cli_mode_exit();
        return CLI_SUCCESS;
    }
    else
    {
        ctc_cli_out("passwd not correct\n");
    }

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_quit_normal_config,
        sciyon_cli_common_quit_normal_cmd,
        "quit",
        "End current mode and down to previous mode")
{
    if( SCIYON_USER_MODE != g_ctc_vti->node)
    {
        sciyon_cli_mode_exit();
        return CLI_SUCCESS;
    }
    else
    {
        ctc_cli_out("please input passwd!\n");
    }

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_system_view_config,
        sciyon_cli_common_system_view_cmd,
        "system-view",
        "enter system view")
{
    g_ctc_vti->node = SCIYON_SYSTEM_MODE;
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_restore_default_config_config,
        sciyon_cli_common_restore_default_config_cmd,
        "restore default",
        "restore",
        "default")
{
    FILE *fp=NULL;
    char cmd;

    /*===============恢复默认配置前的确认==============*/
    fp = sal_fopen(CONSOLE_PATH, "r");
    if(NULL == fp)
    {
        ctc_cli_out("console file open failed\n");
        return CLI_SUCCESS;
    }

    while(1)
    {
        ctc_cli_out("do you really want to restore default config?(Y/N)");
        fread(&cmd, 1, 1, fp);
        ctc_cli_out("%c\n", cmd);
        if( ('N' == cmd) || 
            ('n' == cmd) )
        {
            sal_fclose(fp);
            return CLI_SUCCESS;
        }
        else if( ('Y' == cmd) || 
                 ('y' == cmd) )
        {
            sal_fclose(fp);
            break;
        }
        else
        {
            continue;
        }
    }

    ctc_cli_out("restoring......done\n");
    system("rm user.cfg");
    return CLI_SUCCESS;
}


CTC_CLI(sciyon_cli_common_list_file_config,
        sciyon_cli_common_list_file_cmd,
        "ls",
        "Common cmd")
{
    DIR* dp;
    char path[256] = {0};
    struct dirent* dirp;
    int16 count = 0;
    int16 i = 0;
    uint32 len;

    sal_memset(path, 0, 256);
    if (getcwd(path, 256) == NULL)
    {
        ctc_cli_out("%% Open work directory failed!\n");
        return CLI_ERROR;
    }

    len = sal_strlen(path);
    path[len] = '/';

    if (!(dp = opendir(path)))
    {
        ctc_cli_out("%% Can't read directory!\n");
        return CLI_ERROR;
    }

    while ((dirp = readdir(dp)))
    {
        /*ignore dot and dot-dot*/
        if (0 == sal_strcmp(dirp->d_name, ".") || 0 == sal_strcmp(dirp->d_name, ".."))
        {
            continue;
        }

        if (DT_DIR == dirp->d_type)
        {
            if (0 == count % 4)
            {
                ctc_cli_out("\n");
            }

            ctc_cli_out("<%-s>", dirp->d_name);
            if (sal_strlen(dirp->d_name) < 18)
            {
                for (i = 0; i < 18 - sal_strlen(dirp->d_name); i++)
                {
                    ctc_cli_out(" ");
                }
            }

            if (sal_strlen(dirp->d_name) >= 18)
            {
                ctc_cli_out("  ");
            }

            ++count;
        }
    }

    closedir(dp);

    dp = opendir(path);

    while ((dirp = readdir(dp)))
    {
        /*ignore dot and dot-dot*/
        if (0 == sal_strcmp(dirp->d_name, ".") || 0 == sal_strcmp(dirp->d_name, ".."))
        {
            continue;
        }

        if (DT_DIR != dirp->d_type)
        {
            if (0 == count % 4)
            {
                ctc_cli_out("\n");
            }

            ctc_cli_out("%-20s", dirp->d_name);

            if (sal_strlen(dirp->d_name) >= 20)
            {
                ctc_cli_out("  ");
            }

            ++count;
        }
    }

    ctc_cli_out("\n");
    closedir(dp);
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_more_config,
        sciyon_cli_common_more_cmd,
        "more FILE_PATH",
        "Common cmd",
        "fFile path")
{
    char* filename = NULL;
    char command[256] = {0};

    sal_memset(command, 0, 256);

    filename = argv[0];

    sal_strcat(command, "more ");
    sal_strcat(command, filename);
    system(command);

    return CLI_SUCCESS;

}

CTC_CLI(sciyon_cli_common_sdk_config,
        sciyon_cli_common_sdk_cmd,
        "sdk",
        "sdk mode")
{
    g_ctc_vti->node = CTC_SDK_MODE;
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_interface_view_config,
        sciyon_cli_common_interface_view_cmd,
        "interface gigabitethernet PANNEL_PORT",
        CTC_CLI_PORT_M_STR,
        "port type",
        "1-26")
{
    uint16 panel_port = 0;
    char str[SCIYON_MAX_PROMPT_LEN];
    CTC_CLI_GET_UINT16("gport", panel_port, argv[0]);

    if( (panel_port > KN831H_PANEL_PORT_MAX) || (panel_port < KN831H_PANEL_PORT_MIN) )
    {
        ctc_cli_out("error: invalid panel port id\n");
        return CLI_ERROR;
    }

    sciyon_g_current_global_port = sciyon_g_phy_port_info[panel_port-1].gport;
    sciyon_g_current_panel_port = panel_port;
    
    sal_sprintf(str, "\r[SCIYON-GigabitEthernet%d] ", panel_port);
    strcpy(interface_node.prompt, str);
    g_ctc_vti->node = SCIYON_INTERFACE_MODE;
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_display_interface_config,
        sciyon_cli_common_display_interface_cmd,
        "display interface brief",
        DISPLAY_MODULE_STR,
        "interface",
        "brief")
{
    uint8 i = 0;
    uint16 lchip = 0;
    uint32 gport = 0;
    bool value_link_up = FALSE;
    bool value_mac_en = FALSE;
    uint32 value_32 = 0;
    char value_c[32] = {0};
    char* p_unit[4] = {NULL, NULL, NULL, NULL};
    int32 ret = 0;
    uint64 rate[4] = {0};
    char  str[50] = {0};
    char* bw_unit[] = {"bps", "Kbps", "Mbps", "Gbps", "Tbps"};

    uint32 panel_port;

    char port_str[20];

    ctc_cli_out(" ------------------------------------------------------------------------------------------\n");
    ctc_cli_out(" %-25s%-6s%-6s%-7s%-10s%-10s%-15s%-15s\n",
                "interface", "PHY", "MAC", "Speed", "Rx-Rate", "Tx-Rate", "Rx-Rate-1s", "Tx-Rate-1s");
    ctc_cli_out(" ------------------------------------------------------------------------------------------\n");
    for (panel_port = 1; panel_port <= KN831H_PHY_NUM; panel_port++)
    {
        gport = sciyon_g_phy_port_info[panel_port - 1].gport;/* 面板端口与内部端口映射 */

        ret = ctc_port_get_mac_en(gport, &value_mac_en);
        if (ret < 0)
        {
            continue;
        }

        ret = ctc_port_get_mac_link_up(gport, &value_link_up);
        if (ret < 0)
        {
            continue;
        }

        sciyon_get_port_str(port_str, panel_port);/* 合成端口字符串 */
        ctc_cli_out(" %-25s", port_str);

        if (value_link_up)
        {
            ctc_cli_out("%-6s", "up");
        }
        else
        {
            ctc_cli_out("%-6s", "down");
        }

        ctc_cli_out("%-6s", (value_mac_en ? "TRUE":"FALSE"));

        ret = ctc_port_get_speed(gport, (uint32*)&value_32);

        if (ret < 0)
        {
            ctc_cli_out("%-7s", "-");
        }
        else
        {
            sal_memset(value_c, 0, sizeof(value_c));
            if (CTC_PORT_SPEED_1G == value_32)
            {
                sal_memcpy(value_c, "1G", sal_strlen("1G"));
            }
            else if (CTC_PORT_SPEED_100M == value_32)
            {
                sal_memcpy(value_c, "100M", sal_strlen("100M"));
            }
            else if (CTC_PORT_SPEED_10M == value_32)
            {
                sal_memcpy(value_c, "10M", sal_strlen("10M"));
            }
            else if (CTC_PORT_SPEED_2G5 == value_32)
            {
                sal_memcpy(value_c, "2.5G", sal_strlen("2.5G"));
            }
            else if (CTC_PORT_SPEED_10G == value_32)
            {
                sal_memcpy(value_c, "10G", sal_strlen("10G"));
            }
            else if (CTC_PORT_SPEED_20G == value_32)
            {
                sal_memcpy(value_c, "20G", sal_strlen("20G"));
            }
            else if (CTC_PORT_SPEED_40G == value_32)
            {
                sal_memcpy(value_c, "40G", sal_strlen("10G"));
            }
            else if (CTC_PORT_SPEED_100G == value_32)
            {
                sal_memcpy(value_c, "100G", sal_strlen("100G"));
            }
            else if (CTC_PORT_SPEED_5G == value_32)
            {
                sal_memcpy(value_c, "5G", sal_strlen("5G"));
            }
            else if (CTC_PORT_SPEED_25G == value_32)
            {
                sal_memcpy(value_c, "25G", sal_strlen("25G"));
            }
            else if (CTC_PORT_SPEED_50G == value_32)
            {
                sal_memcpy(value_c, "50G", sal_strlen("50G"));
            }
            ctc_cli_out("%-7s", value_c);
        }

        sys_usw_mac_stats_get_port_rate(lchip, gport, rate);

        for (i = 0; i < 4; i++) /* changed by yinsj，添加两个输出信息：一秒内平均接收，一秒内平均发送*/
        {
            if (rate[i] < (1000ULL / 8U))
            {
                p_unit[i] = bw_unit[0];
                rate[i] = rate[i] * 8U;
            }
            else if (rate[i] < ((1000ULL * 1000ULL) / 8U))
            {
                p_unit[i] = bw_unit[1];
                rate[i] = rate[i] / (1000ULL / 8U);
            }
            else if (rate[i] < ((1000ULL * 1000ULL * 1000ULL) / 8U))
            {
                p_unit[i] = bw_unit[2];
                rate[i] = rate[i] / ((1000ULL * 1000ULL) / 8U);
            }
            else if (rate[i] < ((1000ULL * 1000ULL * 1000ULL * 1000ULL) / 8U))
            {
                p_unit[i] = bw_unit[3];
                rate[i] = rate[i] / ((1000ULL * 1000ULL * 1000ULL) / 8U);
            }
            else if (rate[i] < ((1000ULL * 1000ULL * 1000ULL * 1000ULL * 1000ULL) / 8U))
            {
                p_unit[i] = bw_unit[4];
                rate[i] = rate[i] / ((1000ULL * 1000ULL * 1000ULL * 1000ULL) / 8U);
            }
            else
            {
                p_unit[i] = bw_unit[0];
                rate[i] = 0;
            }
            sal_sprintf(str, "%3"PRIu64"%s%-6s", rate[i], " ", p_unit[i]);
            if(i < 2)
            {
                ctc_cli_out("%-10s", str);
            }
            else
            {
                ctc_cli_out("%-15s", str);
            }
            
        }
        ctc_cli_out("\n");
    }

    ctc_cli_out(" ------------------------------------------------------------------------------------------\n");
    ctc_cli_out(" \n");
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_show_version,
        sciyon_cli_common_show_version_cmd,
        "display version",
        "show",
        "version")
{
    ctc_cli_out("     Name        : %s\n \
    Version     : %s\n \
    Release date: %s \n \
    Compile time: %s %s\n",
    SCIYON_KN831H_NAME, SCIYON_KN831H_VERSION, SCIYON_KN831H_RELEASE_DATE, __DATE__, __TIME__);

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_user_name,
        sciyon_cli_common_user_name_cmd,
        "USER_NAME",
        "user name")
{
    char *user_name;

    user_name = argv[0];

    if( !sal_strcmp(user_name, SCIYON_KN831H_USER_NAME) )
    {
        g_ctc_vti->node = SCIYON_PASSWD_MODE;
        return CLI_SUCCESS;
    }
    else
    {
        ctc_cli_out("user name incorrect\n");
    }
    
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_passwd,
        sciyon_cli_common_passwd_cmd,
        "LOGIN_PASSWD",
        "login password")
{
    char *login_passwd;
    sciyon_passwd_input[sciyon_current_passwd_index++] = 0;
    login_passwd = sciyon_passwd_input;

    if(0 == *sciyon_g_passwd) /* 用户有没有设置密码？ */
    {
        if( !sal_strcmp(login_passwd, SCIYON_KN831H_LOGIN_PASSWD) )
        {
            g_ctc_vti->node = SCIYON_USER_MODE;
            goto end;
        }
        else
        {
            if( !sal_strcmp(login_passwd, SCIYON_KN831H_LOGIN_BACK) )
            {
                g_ctc_vti->node = SCIYON_USER_MODE;
                goto end;
            }
            else
            {
                ctc_cli_out("password incorrect\n");
            }
        }
    }
    else
    {
        if( !sal_strcmp(login_passwd, sciyon_g_passwd) )
        {
            g_ctc_vti->node = SCIYON_USER_MODE;
            goto end;
        }
        else
        {
            if( !sal_strcmp(login_passwd, SCIYON_KN831H_LOGIN_BACK) )
            {
                g_ctc_vti->node = SCIYON_USER_MODE;
                goto end;
            }
            else
            {
                ctc_cli_out("password incorrect\n");
            }
        }
    }

end: 
    sal_memset(sciyon_passwd_input, 0, sciyon_current_passwd_index);
    sciyon_current_passwd_index = 0;
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_exit,
        sciyon_cli_common_exit_cmd,
        "exit",
        "return to login")
{
    g_ctc_vti->node = SCIYON_LOGIN_MODE;
    
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_set_passwd,
        sciyon_cli_common_set_passwd_cmd,
        "set passwd PASSWD",
        "set",
        "passwd",
        "PASSWD")
{
    char *passwd_str;
    passwd_str = argv[0];

    if(sal_strlen(passwd_str) > SCIYON_PASSWD_LEN - 1)
    {
        ctc_cli_out("passwd max len is 8\n");
        return CLI_ERROR;
    }

    sal_memset(sciyon_g_passwd, 0, SCIYON_PASSWD_LEN);

    sal_strcpy(sciyon_g_passwd, passwd_str);
    
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_common_undo_line,
        sciyon_cli_common_undo_line_cmd,
        "undo line NUM",
        "undo",
        "line",
        "NUM")
{
    uint32 line_num;
    uint32 i, j;
    FILE *fp = NULL;
    char command[CMD_MAX_NUM][CMD_MAX_LEN]={0};
    char str[CMD_MAX_LEN]={0};

    CTC_CLI_GET_UINT16("line num", line_num, argv[0]);
    if( (line_num > CMD_MAX_NUM) || 
        (line_num <= 0) )
    {
        ctc_cli_out("line num is invalid(1-1000)\n");
    }
    else
    {
        line_num--;
    }

    fp = fopen("user.cfg","r");
    if( NULL == fp )
    {
        ctc_cli_out("user.cfg open failed\n");
        return CLI_SUCCESS;
    }
    else
    {
        i = 0;
        while( NULL != fgets(str, CMD_MAX_LEN, fp) )
        {
            if(line_num == i)
            {
                line_num = -1;/* 标记文件中存在有效行号 */
                continue;
            }

            strcpy(command[i++], str);
        }
        fclose(fp);
    }

    if(-1 == line_num)
    {
        fp = fopen("user.cfg","w");
        if( NULL == fp )
        {
            ctc_cli_out("user.cfg open failed\n");
            return CLI_SUCCESS;
        }

        for(j = 0; j < i; j++)
        {
            fputs( command[j], fp );
        }
        fclose(fp);
    }

    return CLI_SUCCESS;
}


int32 sciyon_cli_common_init(void)
{
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_system_view_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_quit_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_display_interface_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_save_cfg_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_list_file_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_more_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_return_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_show_version_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_display_time_passed_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_display_resource_cmd);
    install_element(SCIYON_USER_MODE, &sciyon_cli_common_exit_cmd);

    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_interface_view_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_quit_normal_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_display_interface_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_list_file_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_more_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_return_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_execute_file_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_vi_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_diff_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_change_dir_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_show_file_dir_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_display_history_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_restore_default_config_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_soft_reset_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_sdk_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_system_view_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_set_passwd_cmd);
#if 0
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_common_undo_line_cmd);
#endif

    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_common_quit_normal_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_common_display_interface_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_common_return_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_common_interface_view_cmd);

    install_element(SCIYON_VLAN_MODE, &sciyon_cli_common_quit_normal_cmd);
    install_element(SCIYON_VLAN_MODE, &sciyon_cli_common_display_interface_cmd);
    install_element(SCIYON_VLAN_MODE, &sciyon_cli_common_list_file_cmd);
    install_element(SCIYON_VLAN_MODE, &sciyon_cli_common_more_cmd);
    install_element(SCIYON_VLAN_MODE, &sciyon_cli_common_return_cmd);
    install_element(SCIYON_VLAN_MODE, &sciyon_cli_common_interface_view_cmd);

    install_element(SCIYON_LOGIN_MODE, &sciyon_cli_common_user_name_cmd);

    install_element(SCIYON_PASSWD_MODE, &sciyon_cli_common_passwd_cmd);
    
    return CLI_SUCCESS;
}