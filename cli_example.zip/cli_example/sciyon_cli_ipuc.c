/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_ipuc.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-05-20
  
  Description   : ipuc相关CLI源文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-5-20    1.0.0000     初次建立
*************************************************************************************/
#include "sciyon_cli_vlan.h"
#include "sciyon_app.h"
#include "sciyon_cli.h"
#include "common/include/ctc_const.h"
#include "sciyon_save_cfg.h"
#include "sciyon_l3.h"
#include "sciyon_ipuc.h"
#include "sciyon_phy.h"

extern sciyon_ipuc_t sciyon_g_ipuc_pool[SCIYON_IPUC_MAX_NUM];
extern sciyon_mac_addr_t sciyon_g_router_mac;
extern uint16 sciyon_g_ipuc_num;
extern sciyon_phy_info_t sciyon_g_phy_port_info[KN831H_PHY_NUM];
extern uint32 sciyon_g_aging_expire_time;

CTC_CLI(sciyon_cli_ipuc_display_entry_config,
        sciyon_cli_ipuc_display_entry_cmd,
        "display ipuc",
        "display",
        "ipuc")
{
    int i, j;
    char ipucstr[20];
    uint8 *ip=NULL;
    uint8 *mac=NULL;
    uint32 panel_port=0;
    uint32 nh_id;
    uint32 vlan_id;
    uint16 aging_timer;

    ctc_cli_out("IP              NHID     MAC                 PORT     VLAN    AGING\n");
    ctc_cli_out("--------------------------------------------------------------------\n");
    for(i = 0; i < sciyon_g_ipuc_num; i++)
    {
        ip = sciyon_g_ipuc_pool[i].ip;
        mac = sciyon_g_ipuc_pool[i].mac;
        vlan_id = sciyon_g_ipuc_pool[i].vlan_id;
        nh_id = sciyon_g_ipuc_pool[i].nh_id;
        aging_timer = sciyon_g_ipuc_pool[i].aging_timer;
        for(j = 0; j < KN831H_PHY_NUM; j++)
        {
            if(sciyon_g_ipuc_pool[i].gport == sciyon_g_phy_port_info[j].gport)
            {
                panel_port = j + 1;
                break;
            }
        }
        sal_sprintf(ipucstr, "%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]);
        ctc_cli_out("%-16s", ipucstr);
        sal_sprintf(ipucstr, "%d", nh_id);
        ctc_cli_out("%-9s", ipucstr);
        sal_sprintf(ipucstr, "%02x%02x.%02x%02x.%02x%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
        ctc_cli_out("%-20s", ipucstr);
        sal_sprintf(ipucstr, "%d", panel_port);
        ctc_cli_out("%-9s", ipucstr);       
        sal_sprintf(ipucstr, "%d", vlan_id);
        ctc_cli_out("%-8s", ipucstr);
        sal_sprintf(ipucstr, "%d", aging_timer);
        ctc_cli_out("%-9s\n", ipucstr);
    }
    ctc_cli_out("--------------------------------------------------------------------\n");
    ctc_cli_out("used: %d/%d\n", sciyon_g_ipuc_num, SCIYON_IPUC_MAX_NUM);
    return CLI_SUCCESS;
}

int32 sciyon_cli_ipuc_init(void)
{
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_ipuc_display_entry_cmd);
    
    return CLI_SUCCESS;
}