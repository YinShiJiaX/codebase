/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_security.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-05-28
  
  Description   : security相关CLI的源文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-5-28    1.0.0000     初次建立
*************************************************************************************/
#include "api/include/ctc_api.h"
#include "sciyon_cli_port.h"
#include "sciyon_cli.h"
#include "sciyon_app.h"
#include "sciyon_cli_security.h"
#include "sciyon_phy.h"

extern sciyon_phy_info_t sciyon_g_phy_port_info[KN831H_PHY_NUM];

CTC_CLI(sciyon_cli_security_storm_ctl_config,
        sciyon_cli_security_storm_ctl_cmd,
        "storm-control VALUE",
        "storm control",
        "value<MB>")
{
    int i;
    uint16 threshold;
    ctc_security_stmctl_cfg_t storm_ctl_config;

    CTC_CLI_GET_UINT16("threshold value", threshold, argv[0]);

    sal_memset(&storm_ctl_config, 0, sizeof(storm_ctl_config));
    storm_ctl_config.mode             = CTC_SECURITY_STORM_CTL_MODE_KBPS;
    storm_ctl_config.storm_en         = 1; 
    storm_ctl_config.discarded_to_cpu = 0;
    storm_ctl_config.threshold        = threshold * 1000;/* threshold MB */

    for(i = 0; i < KN831H_PHY_NUM; i++)
    {
        storm_ctl_config.type             = CTC_SECURITY_STORM_CTL_BCAST;/* 广播风暴控制 */
        storm_ctl_config.gport            = sciyon_g_phy_port_info[i].gport;
        ctc_storm_ctl_set_cfg( &storm_ctl_config );

        storm_ctl_config.type             = CTC_SECURITY_STORM_CTL_KNOWN_MCAST;/* 已知多播风暴控制 */
        ctc_storm_ctl_set_cfg( &storm_ctl_config );

        storm_ctl_config.type             = CTC_SECURITY_STORM_CTL_UNKNOWN_MCAST;/* 未知多播风暴控制 */
        ctc_storm_ctl_set_cfg( &storm_ctl_config );
    }

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_security_storm_ctl_display_config,
        sciyon_cli_security_storm_ctl_display_cmd,
        "display storm-control",
        "display",
        "storm control")
{
    ctc_security_stmctl_cfg_t storm_ctl_config;

    sal_memset(&storm_ctl_config, 0, sizeof(storm_ctl_config));
    storm_ctl_config.type             = CTC_SECURITY_STORM_CTL_BCAST;/* 广播风暴控制 */
    storm_ctl_config.gport            = 0x0000;/* KN831H的风暴控制是全局的，所以一个端口的阈值即可代表所有端口 */

    ctc_storm_ctl_get_cfg(&storm_ctl_config);

    ctc_cli_out("-------------------------------\n");
    /* threadhold单位为KBPS */
    ctc_cli_out("storm control vlaue: %d MB(Bytes)\n", storm_ctl_config.threshold / 1000);
    ctc_cli_out("-------------------------------\n");

    return CLI_SUCCESS;
}

int32 sciyon_cli_security_init(void)
{
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_security_storm_ctl_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_security_storm_ctl_display_cmd);
    return CLI_SUCCESS;
}