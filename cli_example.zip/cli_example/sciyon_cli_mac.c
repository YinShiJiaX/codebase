/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_mac.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-04-12 
  
  Description   : mac相关CLI的源文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-4-12    1.0.0000     初次建立
*************************************************************************************/
#include "sciyon_cli_mac.h"
#include "sciyon_app.h"
#include "sciyon_phy.h"
#include "sciyon_cli.h"

extern sciyon_phy_info_t sciyon_g_phy_port_info[KN831H_PHY_NUM];

CTC_CLI(sciyon_cli_mac_display_mac_addr_config,
        sciyon_cli_mac_display_mac_addr_cmd,
        "display mac-address all",
        DISPLAY_MODULE_STR, 
        "mac-address",
        "all")
{
    int32 ret  = CLI_SUCCESS;
    uint8 index = 0;
    uint32 i;
    ctc_l2_fdb_query_rst_t query_rst;
    ctc_l2_write_info_para_t* write_entry_para = NULL;
    uint32 total_count = 0;
    ctc_l2_fdb_query_t Query;
    uint16 entry_cnt = 0;
    uint32 count = 0;

    sal_memset(&query_rst, 0, sizeof(ctc_l2_fdb_query_rst_t));
    sal_memset(&Query, 0, sizeof(ctc_l2_fdb_query_t));

    Query.query_type = CTC_L2_FDB_ENTRY_OP_ALL;
    Query.query_flag = CTC_L2_FDB_ENTRY_ALL;

    entry_cnt = 100;
    {
        query_rst.buffer_len = sizeof(ctc_l2_addr_t) * entry_cnt;
        query_rst.buffer = (ctc_l2_addr_t*)mem_malloc(MEM_CLI_MODULE, query_rst.buffer_len);
        if (NULL == query_rst.buffer)
        {
            ctc_cli_out("%% Alloc  memory  failed \n");
            if (write_entry_para)
            {
                mem_free(write_entry_para);
            }
            return CLI_ERROR;
        }

        sal_memset(query_rst.buffer, 0, query_rst.buffer_len);

        ctc_cli_out(" %-20s%-6s%-6s%-10s\n", "MAC Address", "VLAN", "Port", "Type");
        ctc_cli_out(" -------------------------------------------\n");

        do
        {
            query_rst.start_index = query_rst.next_query_index;

            ret = ctc_l2_get_fdb_entry(&Query, &query_rst);
            if (ret < 0)
            {
                ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
                mem_free(query_rst.buffer);
                query_rst.buffer = NULL;
                if (write_entry_para)
                {
                    mem_free(write_entry_para);
                }
                return CLI_ERROR;
            }

            for(index = 0; index < Query.count; index++)/* 端口重映射 */
            {
                for(i = 0; i < KN831H_PHY_NUM; i++)
                {
                    if(sciyon_g_phy_port_info[i].gport == query_rst.buffer[index].gport)
                    {
                        query_rst.buffer[index].gport = i + 1;
                        break;
                    }
                }
            }

            for (index = 0; index < Query.count; index++)
            {
                ctc_cli_out(" %.4x.%.4x.%.4x%4s  ", sal_ntohs(*(unsigned short*)&query_rst.buffer[index].mac[0]),
                            sal_ntohs(*(unsigned short*)&query_rst.buffer[index].mac[2]),
                            sal_ntohs(*(unsigned short*)&query_rst.buffer[index].mac[4]),
                            " ");

                ctc_cli_out("%.4d  ", query_rst.buffer[index].fid);
                ctc_cli_out("GE-%.2d  ", query_rst.buffer[index].gport);
                ctc_cli_out("%4s\n", (query_rst.buffer[index].flag & CTC_L2_FLAG_IS_STATIC) ? "Static" : "Dynamic");
                sal_memset(&query_rst.buffer[index], 0, sizeof(ctc_l2_addr_t));
                count++;
            }

            total_count += count;
            sal_task_sleep(100);

        }
        while (query_rst.is_end == 0);

        ctc_cli_out(" -------------------------------------------\n");
        ctc_cli_out(" Total Entry Num: %d\n", total_count);

        mem_free(query_rst.buffer);
        query_rst.buffer = NULL;

        if (write_entry_para)
        {
            mem_free(write_entry_para);
        }

    }

    return CLI_SUCCESS;
}

int32 sciyon_cli_mac_init(void)
{
    install_element(SCIYON_USER_MODE, &sciyon_cli_mac_display_mac_addr_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_mac_display_mac_addr_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_mac_display_mac_addr_cmd);
    install_element(SCIYON_VLAN_MODE, &sciyon_cli_mac_display_mac_addr_cmd);

    return CLI_SUCCESS;
}