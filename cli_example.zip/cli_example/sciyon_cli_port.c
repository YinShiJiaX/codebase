/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_port.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-04-12 
  
  Description   : port相关CLI源文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-4-12    1.0.0000     初次建立
*************************************************************************************/
#include "sciyon_cli_port.h"
#include "sciyon_app.h"
#include "sciyon_cli.h"
#include "sciyon_phy.h"
#include "common/include/ctc_const.h"
#include "common/include/ctc_port.h"
#include "sciyon_cli_acl.h"
#include "sciyon_cli_vlan.h"

extern sciyon_phy_info_t sciyon_g_phy_port_info[KN831H_PHY_NUM];
extern sciyon_acl_t sciyon_g_acl_pool[SCIYON_MAX_ACL_COUNT];
extern uint8 sciyon_g_acl_num;

CTC_CLI(sciyon_cli_port_linktype_config,
        sciyon_cli_port_linktype_cmd,
        "port link-type access",
        PORT_MODULE_STR, 
        "link type(only access)",
        "access")
{
    ctc_vlantag_ctl_t mode;
    ctc_direction_t dir;

    mode = CTC_VLANCTL_DROP_ALL_TAGGED;
    dir    = CTC_BOTH_DIRECTION;
    
    /* 配置端口为Access端口*/
    ctc_port_set_vlan_ctl(sciyon_g_current_global_port, mode);
    ctc_port_set_vlan_filter_en(sciyon_g_current_global_port, dir, TRUE);
    
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_port_display_vlan_config,
        sciyon_cli_port_display_vlan_cmd,
        "display port vlan",
        "display", 
        "port",
        "vlan")
{
    int i;
    char portstr[23];
    uint16 default_vlan;

    ctc_cli_out("Port                   Link Type      VLAN\n");
    ctc_cli_out("----------------------------------------------------------------\n");
    for(i = 0; i < KN831H_PHY_NUM; i++)
    {
        ctc_port_get_default_vlan(sciyon_g_phy_port_info[i].gport, &default_vlan);

        sal_sprintf(portstr, "GigabitEthernet%d", i + 1);
        ctc_cli_out("%-23s", portstr);
        ctc_cli_out("%-15s", "access");
        ctc_cli_out("%-4d\n", default_vlan);
    }
    ctc_cli_out("----------------------------------------------------------------\n");
    ctc_cli_out("default vlan: 1\n");
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_port_display_vlan_port_config,
        sciyon_cli_port_display_vlan_port_cmd,
        "display port vlan gigabitethernet PORT",
        "display", 
        "port",
        "vlan",
        "GE",
        "port<1-26>")
{
    char portstr[23];
    uint16 default_vlan;
    uint32 panel_port;

    CTC_CLI_GET_UINT32("port", panel_port, argv[0]);
    if( (panel_port < KN831H_PANEL_PORT_MIN) || (panel_port > KN831H_PANEL_PORT_MAX) )
    {
        ctc_cli_out("error: invalid port\n");
        return CLI_ERROR;
    }

    ctc_port_get_default_vlan(sciyon_g_phy_port_info[panel_port - 1].gport, &default_vlan);

    ctc_cli_out("Port                   Link Type      VLAN\n");
    ctc_cli_out("----------------------------------------------------------------\n");
    sal_sprintf(portstr, "GigabitEthernet%d", panel_port);
    ctc_cli_out("%-23s", portstr);
    ctc_cli_out("%-15s", "access");
    ctc_cli_out("%-4d\n", default_vlan);
    ctc_cli_out("----------------------------------------------------------------\n");
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_port_shutdown_config,
        sciyon_cli_port_shutdown_cmd,
        "shutdown",
        "shutdown port")
{
    int32 ret = CLI_SUCCESS;
    ctc_chip_mdio_type_t type;
    ctc_chip_mdio_para_t mdio_para;

    sal_memset(&mdio_para, 0, sizeof(ctc_chip_mdio_para_t));

    type = CTC_CHIP_MDIO_GE;
    mdio_para.ctl_id = 0;
    mdio_para.reg = 0;
    mdio_para.bus = sciyon_g_phy_port_info[sciyon_g_current_panel_port-1].bus;
    mdio_para.phy_addr = sciyon_g_phy_port_info[sciyon_g_current_panel_port-1].addr;

    /* 记录端口状态，用于配置保存 */
    sciyon_g_phy_port_info[sciyon_g_current_panel_port-1].status = 0;

    /* 关闭mac和port*/
    ret = ctc_port_set_mac_en(sciyon_g_current_global_port, FALSE);
    ret = ctc_port_set_port_en(sciyon_g_current_global_port, FALSE);

    /* 关闭phy */
    mdio_para.value = SHUTDOWN_PHY;
    ctc_chip_mdio_write(0, type,  &mdio_para);

    if ((ret < 0) && ((ret != -9911) && (ret != -9907)&&(ret!=CTC_E_INVALID_CONFIG)))
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
    }
    
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_port_undo_shutdown_config,
        sciyon_cli_port_undo_shutdown_cmd,
        "undo shutdown",
        "activate port")
{
    int32 ret = CLI_SUCCESS;
    ctc_chip_mdio_type_t type;
    ctc_chip_mdio_para_t mdio_para;

    sal_memset(&mdio_para, 0, sizeof(ctc_chip_mdio_para_t));

    type = CTC_CHIP_MDIO_GE;
    mdio_para.ctl_id = 0;
    mdio_para.reg = 0;
    mdio_para.bus = sciyon_g_phy_port_info[sciyon_g_current_panel_port-1].bus;
    mdio_para.phy_addr = sciyon_g_phy_port_info[sciyon_g_current_panel_port-1].addr;

    /* 记录端口状态，用于配置保存 */
    sciyon_g_phy_port_info[sciyon_g_current_panel_port-1].status = 1;

    /* 打开mac和port*/
    ret = ctc_port_set_mac_en(sciyon_g_current_global_port, TRUE);
    ret = ctc_port_set_port_en(sciyon_g_current_global_port, TRUE);

    /* 打开phy */
    mdio_para.value = UN_SHUTDOWN_PHY;
    ctc_chip_mdio_write(0, type,  &mdio_para);

    if ((ret < 0) && ((ret != -9911) && (ret != -9907)&&(ret!=CTC_E_INVALID_CONFIG)))
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
    }
    
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_port_flow_ctrl_config,
        sciyon_cli_port_flow_ctrl_cmd,
        "flow-control",
        "configure flow-control operation model")
{
    int32 ret = CLI_SUCCESS;
    ctc_port_fc_prop_t fc_param;

    sal_memset(&fc_param, 0, sizeof(ctc_port_fc_prop_t));

    fc_param.gport = sciyon_g_current_global_port;
    fc_param.dir = CTC_BOTH_DIRECTION;
    fc_param.enable = 1;

    ret = ctc_port_set_flow_ctl_en(&fc_param);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(sciyon_cli_port_undo_flow_ctrl_config,
        sciyon_cli_port_undo_flow_ctrl_cmd,
        "undo flow-control",
        "Cancel the setting")
{
    int32 ret = CLI_SUCCESS;
    ctc_port_fc_prop_t fc_param;

    sal_memset(&fc_param, 0, sizeof(ctc_port_fc_prop_t));

    fc_param.gport = sciyon_g_current_global_port;
    fc_param.dir = CTC_BOTH_DIRECTION;
    fc_param.enable = 0;

    ret = ctc_port_set_flow_ctl_en(&fc_param);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(sciyon_cli_port_add_vlan_config,
        sciyon_cli_port_add_vlan_cmd,
        "port default vlan VLAN_ID",
        PORT_MODULE_STR, 
        "default(only access)",
        "vlan",
        "VLAN ID<10-35>")
{
    uint16 vlan_id;
    uint16 default_vlan;
    bool vlan_create = 0;

    CTC_CLI_GET_UINT16("vlan id", vlan_id, argv[0]);

    if( (vlan_id > SCIYON_MAX_VLAN_ID) || (vlan_id < SCIYON_MIN_VLAN_ID))
    {
        ctc_cli_out("error: vlan id invalid\n");
        return CLI_ERROR;
    }

    /* 检查新的vlan是否创建 */
    ctc_vlan_get_receive_en(vlan_id, &vlan_create);
    if(!vlan_create)
    {
        ctc_cli_out("error: vlan %d not exist\n", vlan_id);
        return CLI_ERROR;
    }

    /* 将端口从原来的vlan移除 */
    ctc_port_get_default_vlan(sciyon_g_current_global_port, &default_vlan);
    ctc_vlan_remove_port(default_vlan, sciyon_g_current_global_port);

    /* 将端口加入新的vlan */
    ctc_port_set_default_vlan(sciyon_g_current_global_port, vlan_id);
    ctc_vlan_add_port(vlan_id, sciyon_g_current_global_port);

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_port_install_acl_config,
        sciyon_cli_port_install_acl_cmd,
        "traffic-filter (inbound | outbound) (acl ACL_NUM)",
        "traffic-filter",
        "outbound",
        "inbound",
        "acl", 
        "acl number")
{
    int32 ret = CLI_SUCCESS;
    uint8 direction;
    uint8 rule_id=0;
    uint8 index;
    uint8 acl_exists = 0;
    uint32 entry_id;
    uint32 group_id;
    uint32 ip;
    uint32 netmask;
    ctc_acl_entry_t acl_entry;
    ctc_field_key_t key_field;
    ctc_acl_field_action_t action_field;

    index = CTC_CLI_GET_ARGC_INDEX("outbound");
    if(0xFF != index)
    {
        direction= SCIYON_ACL_OUT;
    }
    else
    {
        direction= SCIYON_ACL_IN;
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl");
    if(0xFF != index)
    {
        CTC_CLI_GET_UINT8( "rule id", rule_id, argv[index+1] );
    }

    /* 找到软acl表对应的ip和netmask */
    for(int i = 0; i < sciyon_g_acl_num; i++)
    {
        if(rule_id == sciyon_g_acl_pool[i].rule_id)
        {
            ip = *(uint32 *)(sciyon_g_acl_pool[i].ip);
            netmask = *(uint32 *)(sciyon_g_acl_pool[i].netmask);
            acl_exists = 1;
            break;
        }
    }

    if(!acl_exists)
    {
        ctc_cli_out("error: rule id doesn't exits\n");
        return CLI_ERROR;
    }

    /* 根据对当前 （端口） 和 （过滤方向） 确定对应的全局（ACL group id） */
    group_id = (2 * (sciyon_g_current_panel_port - 1) + direction);
    /* 根据对当前（端口）、（方向）以及（用户 entry_id）确定对应的全局 （ACL entry id） */
    entry_id = SCIYON_MAX_ACL_COUNT * (2 * (sciyon_g_current_panel_port - 1) + direction )  + rule_id;

    /* 向对应ACL group中添加一个entry */
    sal_memset(&acl_entry, 0, sizeof(ctc_acl_entry_t));
    acl_entry.entry_id = entry_id;
    acl_entry.key_type = CTC_ACL_KEY_IPV4;
    acl_entry.mode = 1;
    ret = ctc_acl_add_entry(group_id, &acl_entry);
    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
     
    /* 为entry添加key-field */
    /* 添加 l3-type 域 */
    sal_memset(&key_field, 0, sizeof(ctc_field_key_t));
    key_field.type = CTC_FIELD_KEY_L3_TYPE;
    key_field.data = 2;
    key_field.mask = 0xF;
    ctc_acl_add_key_field(entry_id, &key_field);

    /* 添加 ip-sa 域 */
    sal_memset(&key_field, 0, sizeof(ctc_field_key_t));
    key_field.type = CTC_FIELD_KEY_IP_SA;    
    key_field.data = ip;
    key_field.mask = netmask;
    ctc_acl_add_key_field(entry_id, &key_field);

    /* 为entry添加action */
    sal_memset(&action_field, 0, sizeof(ctc_acl_field_action_t));
    action_field.type = CTC_ACL_FIELD_ACTION_DISCARD;
    ctc_acl_add_action_field(entry_id, &action_field);

    ret = ctc_acl_install_entry(entry_id);
    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(sciyon_cli_port_undo_install_acl_config,
        sciyon_cli_port_undo_install_acl_cmd,
        "undo traffic-filter (inbound | outbound) (acl ACL_NUM)",
        "undo",
        "traffic-filter",
        "outbound",
        "inbound",
        "acl", 
        "acl number")
{
    int32 ret = CLI_SUCCESS;
    uint8 direction;
    uint8 rule_id=0;
    uint8 index;
    uint32 entry_id;

    index = CTC_CLI_GET_ARGC_INDEX("outbound");
    if(0xFF != index)
    {
        direction= SCIYON_ACL_OUT;
    }
    else
    {
        direction= SCIYON_ACL_IN;
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl");
    if(0xFF != index)
    {
        CTC_CLI_GET_UINT8( "rule id", rule_id, argv[index+1] );
    }

    /* 根据对当前（端口）、（方向）以及（用户 entry_id）确定对应的全局 （ACL entry id） */
    entry_id = SCIYON_MAX_ACL_COUNT * (2 * (sciyon_g_current_panel_port - 1) + direction )  + rule_id;

    /* uninstall entry*/
    ret = ctc_acl_uninstall_entry(entry_id);
    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    /*  remove entry */
    ret = ctc_acl_remove_entry(entry_id);
    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

int32 sciyon_cli_port_init(void)
{
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_port_linktype_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_port_add_vlan_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_port_flow_ctrl_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_port_undo_flow_ctrl_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_port_shutdown_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_port_undo_shutdown_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_port_install_acl_cmd);
    install_element(SCIYON_INTERFACE_MODE, &sciyon_cli_port_undo_install_acl_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_port_display_vlan_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_port_display_vlan_port_cmd);
    return CLI_SUCCESS;
}