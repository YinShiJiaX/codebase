/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_l3.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-07-19
  
  Description   : l3相关CLI源文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-7-19    1.0.0000     初次建立
*************************************************************************************/
#include "sciyon_cli_vlan.h"
#include "sciyon_app.h"
#include "sciyon_cli.h"
#include "common/include/ctc_const.h"
#include "sciyon_save_cfg.h"
#include "sciyon_l3.h"
#include "sciyon_ipuc.h"
#include "sciyon_phy.h"

extern sciyon_mac_addr_t sciyon_g_router_mac;
extern uint32 sciyon_g_aging_expire_time;

CTC_CLI(sciyon_cli_l3_display_router_mac_config,
        sciyon_cli_l3_display_router_mac_cmd,
        "display router-mac",
        "display",
        "global mac")
{
    ctc_cli_out("router mac: ");
    ctc_cli_out("%02x%02x.%02x%02x.%02x%02x\n", sciyon_g_router_mac[0], sciyon_g_router_mac[1],
                                                sciyon_g_router_mac[2], sciyon_g_router_mac[3],
                                                sciyon_g_router_mac[4], sciyon_g_router_mac[5]);
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_l3_set_router_mac_config,
        sciyon_cli_l3_set_router_mac_cmd,
        "set router-mac MAC",
        "set",
        "router mac")
{
    sciyon_mac_addr_t mac;
    CTC_CLI_GET_MAC_ADDRESS("mac address", mac, argv[0]);
    sal_memcpy(sciyon_g_router_mac, mac, SCIYON_MAC_ADDR_LEN);
    ctc_l3if_set_router_mac(mac);
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_l3_set_aging_time_config,
        sciyon_cli_l3_set_aging_time_cmd,
        "set aging time TIME",
        "set",
        "aging",
        "time",
        "TIME")
{
    uint32 aging_expire_time = 0;
    CTC_CLI_GET_UINT32("aging time", aging_expire_time, argv[0]);

    sciyon_g_aging_expire_time = aging_expire_time * 60;

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_l3_display_aging_time_config,
        sciyon_cli_l3_display_aging_time_cmd,
        "display aging time",
        "display",
        "aging",
        "time")
{
    ctc_cli_out("aging time: %d minutes\n", sciyon_g_aging_expire_time / 60);
    
    return CLI_SUCCESS;
}

int32 sciyon_cli_l3_init(void)
{
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_l3_display_router_mac_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_l3_set_router_mac_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_l3_set_aging_time_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_l3_display_aging_time_cmd);

    return CLI_SUCCESS;
}