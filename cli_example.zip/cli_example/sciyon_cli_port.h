/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_port.h
  Author: yinsj             Version: 1.0.0000          Data: 2021-04-12 
  
  Description   : port相关CLI的头文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-4-12    1.0.0000     初次建立
*************************************************************************************/
#ifndef _SCIYON_CLI_PORT_H
#define _SCIYON_CLI_PORT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sal_types.h"

#define SHUTDOWN_PHY    (0x0800)
#define UN_SHUTDOWN_PHY (0x9000)
#define SCIYON_ACL_OUT  0
#define SCIYON_ACL_IN   1

int32 sciyon_cli_port_init(void);

#ifdef __cplusplus
}
#endif

#endif /* _SCIYON_CLI_PORT_H */