/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-04-02 
  
  Description   : CLI初始化源文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-4-2    1.0.0000     初次建立
*************************************************************************************/
#include "api/include/ctc_api.h"
#include "ctc_cli.h"
#include "ctc_app_packet.h"
#include "ctc_cli_common.h"
#include "ctc_app.h"
#include "ctc_app_warmboot.h"
#include "ctc_app_flow_recorder.h"
#include "sciyon_cli.h"
#include "sciyon_cli_common.h"
#include "sciyon_cli_mac.h"
#include "sciyon_cli_port.h"
#include "sciyon_cli_vlan.h"
#include "sciyon_cli_ipmc.h"
#include "sciyon_cli_ipuc.h"
#include "sciyon_cli_acl.h"
#include "sciyon_cli_security.h"
#include "sciyon_cli_l3.h"

extern uint32 sciyon_g_current_panel_port;
extern uint32 sciyon_g_current_global_port;
extern uint32 sciyon_g_current_vlan_id;

extern char sciyon_g_passwd[SCIYON_PASSWD_LEN];
extern char sciyon_passwd_input[SCIYON_PASSWD_INPUT_LEN];
extern uint8 sciyon_current_passwd_index;

ctc_cmd_node_t user_node =
{
    SCIYON_USER_MODE,
    "\r<SCIYON> ",
};

ctc_cmd_node_t system_node =
{
    SCIYON_SYSTEM_MODE,
    "\r[SCIYON] ",
};

ctc_cmd_node_t interface_node =
{
    SCIYON_INTERFACE_MODE,
    "\r[SCIYON-GigabitEthernet-Port] ",
};

ctc_cmd_node_t vlan_node =
{
    SCIYON_VLAN_MODE,
    "\r[SCIYON-Vlan-Num] ",
};

ctc_cmd_node_t login_node =
{
    SCIYON_LOGIN_MODE,
    "\rLOGIN: ",
};

ctc_cmd_node_t passwd_node =
{
    SCIYON_PASSWD_MODE,
    "\rPASSWD: ",
};

void sciyon_back_to_user_mode(void)
{
    g_ctc_vti->node = SCIYON_USER_MODE;
}

/*
 * 这个函数会被 /home/yinsj/switch-project/ctcsdk5.5.9/ctccli/ctc_master_cli.c： ctc_cli_init 调用
 */
int32 sciyon_cli_init(void)
{
#if 0
    ctc_debug_register_cb(ctc_cli_out);
    ctc_debug_register_log_cb(ctc_cli_out);

    ctc_cmd_init(0);
#endif

    /* Install sciyon nodes. */
    ctc_install_node(&user_node, NULL);
    ctc_install_node(&system_node, NULL);
    ctc_install_node(&interface_node, NULL);
    ctc_install_node(&vlan_node, NULL);
    ctc_install_node(&login_node, NULL);
    ctc_install_node(&passwd_node, NULL);

    ctc_vti_init(SCIYON_LOGIN_MODE);

    sciyon_cli_common_init();
    sciyon_cli_mac_init();
    sciyon_cli_port_init();
    sciyon_cli_vlan_init();
    sciyon_cli_ipmc_init();
    sciyon_cli_acl_init();
    sciyon_cli_ipuc_init();
    sciyon_cli_security_init();
    sciyon_cli_l3_init();

#if 0
    ctc_sort_node();
#endif

    return CLI_SUCCESS;
}