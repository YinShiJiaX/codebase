/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_acl.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-05-13 
  
  Description   : ACL
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-5-13    1.0.0000     初次建立
*************************************************************************************/

#include "sal_types.h"
#include "sal.h"
#include "ctc_cli.h"
#include "common/include/ctc_acl.h"
#include "api/include/ctc_api.h"
#include "sciyon_l3.h"
#include "sciyon_cli_acl.h"
#include "sciyon_cli.h"

extern sciyon_acl_t sciyon_g_acl_pool[SCIYON_MAX_ACL_COUNT];
extern uint8 sciyon_g_acl_num;

void sciyon_soft_acl_pool_clear(void)
{
    sal_memset(sciyon_g_acl_pool, 0, sizeof(sciyon_acl_t) * SCIYON_MAX_ACL_COUNT);
    sciyon_g_acl_num = 0;
}

CTC_CLI(sciyon_cli_acl_add_rule_config,
        sciyon_cli_acl_add_rule_cmd,
        "acl number RULE_ID deny source ip IP_ADDR NET_MASK",
        "acl",
        "number",
        "number id<0-23>",
        "deny",
        "ip",
        "source",
        "ip address",
        "net mask")
{
    uint32 rule_id;
    uint32 ip;
    uint32 netmask;
    uint32 i;

    if(sciyon_g_acl_num >= SCIYON_MAX_ACL_COUNT)
    {
        ctc_cli_out("error: acl count is no more than %d\n", SCIYON_MAX_ACL_COUNT);
        return CLI_ERROR;
    }

    CTC_CLI_GET_UINT32("rule id", rule_id, argv[0]);
    if( (rule_id < SCIYON_MIN_ACL_NUMBER) || (rule_id > SCIYON_MAX_ACL_NUMBER) )
    {
        ctc_cli_out("error: invalid acl number<0-23>\n");
        return CLI_ERROR;
    }

    for(i = 0; i < sciyon_g_acl_num; i++ )
    {
        if(rule_id == sciyon_g_acl_pool[i].rule_id)
        {
            ctc_cli_out("acl id already used !\n");
            return CLI_SUCCESS;
        }
    }

    CTC_CLI_GET_IPV4_ADDRESS("ip address", ip, argv[1]);
    CTC_CLI_GET_IPV4_ADDRESS("netmask", netmask, argv[2]);

    /* 在acl软表中记录 */
    sciyon_g_acl_pool[sciyon_g_acl_num].rule_id = rule_id;
    *(uint32 *)(sciyon_g_acl_pool[sciyon_g_acl_num].ip) = ip;
    *(uint32 *)(sciyon_g_acl_pool[sciyon_g_acl_num].netmask) = netmask;
    sciyon_g_acl_num++;

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_acl_undo_add_rule_config,
        sciyon_cli_acl_undo_add_rule_cmd,
        "undo acl number RULE_ID deny source ip IP_ADDR NET_MASK",
        "undo",
        "acl",
        "number",
        "number id<0-23>",
        "deny",
        "ip",
        "source",
        "ip address",
        "net mask")
{
    uint32 rule_id;
    uint32 ip;
    uint32 netmask;
    uint32 i;
    uint8 found = 0;

    CTC_CLI_GET_UINT32("rule id", rule_id, argv[0]);
    if( (rule_id < SCIYON_MIN_ACL_NUMBER) || (rule_id > SCIYON_MAX_ACL_NUMBER) )
    {
        ctc_cli_out("error: invalid acl number<0-23>\n");
        return CLI_ERROR;
    }

    if(sciyon_g_acl_num <= 0)
    {
        ctc_cli_out("acl num is zero\n");
        return CLI_ERROR;
    }

    CTC_CLI_GET_IPV4_ADDRESS("ip address", ip, argv[1]);
    CTC_CLI_GET_IPV4_ADDRESS("netmask", netmask, argv[2]);

    for(i = 0; i < sciyon_g_acl_num; i++ )
    {
        if( (sciyon_g_acl_pool[i].rule_id == rule_id)             &&
            (*(uint32 *)(sciyon_g_acl_pool[i].ip) == ip)          &&
            (*(uint32 *)(sciyon_g_acl_pool[i].netmask) == netmask) )
        {
            found = 1;/* 找到了需要删除的rule id */
        }

        if(found)
        {
            sciyon_g_acl_pool[i].rule_id = sciyon_g_acl_pool[i+1].rule_id;
            *(uint32 *)sciyon_g_acl_pool[i].ip = *(uint32 *)sciyon_g_acl_pool[i+1].ip;
            *(uint32 *)sciyon_g_acl_pool[i].netmask = *(uint32 *)sciyon_g_acl_pool[i+1].netmask;
        }
    }

    if(found)
    {
        sciyon_g_acl_num--;
        return CLI_SUCCESS;
    }

    ctc_cli_out("rule not exist\n");

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_acl_display_rule_config,
        sciyon_cli_acl_display_rule_cmd,
        "display acl",
        "display",
        "acl")
{
    int i;
    char aclstr[20];

    ctc_cli_out("-------------------------------------------------------\n");
    ctc_cli_out("ID   ACTION     IP                  NETMASK\n");
    for(i = 0; i < sciyon_g_acl_num; i++)
    {
        sal_sprintf(aclstr, "%d", sciyon_g_acl_pool[i].rule_id);
        ctc_cli_out("%-5s", aclstr);
        ctc_cli_out("%-11s", "deny");
        sal_sprintf(aclstr, "%d.%d.%d.%d", sciyon_g_acl_pool[i].ip[3], sciyon_g_acl_pool[i].ip[2],
                                           sciyon_g_acl_pool[i].ip[1], sciyon_g_acl_pool[i].ip[0]);
        ctc_cli_out("%-20s", aclstr);
        sal_sprintf(aclstr, "%d.%d.%d.%d", sciyon_g_acl_pool[i].netmask[3], sciyon_g_acl_pool[i].netmask[2],
                                           sciyon_g_acl_pool[i].netmask[1], sciyon_g_acl_pool[i].netmask[0]);
        ctc_cli_out("%-20s\n", aclstr);
    }
    ctc_cli_out("-------------------------------------------------------\n");
    ctc_cli_out("used: %d/%d\n", sciyon_g_acl_num, SCIYON_MAX_ACL_COUNT);
    return CLI_SUCCESS;
}

int32 sciyon_cli_acl_init(void)
{
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_acl_add_rule_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_acl_display_rule_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_acl_undo_add_rule_cmd);
    return CLI_SUCCESS;
}