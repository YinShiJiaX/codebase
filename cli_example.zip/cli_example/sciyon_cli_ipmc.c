/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli_ipmc.c
  Author: yinsj             Version: 1.0.0000          Data: 2021-05-12
  
  Description   : IPMC
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-5-12    1.0.0000     初次建立
*************************************************************************************/

#include "sal_types.h"
#include "sal.h"
#include "ctc_cli.h"
#include "common/include/ctc_ipmc.h"
#include "api/include/ctc_api.h"
#include "sciyon_l3.h"
#include "sciyon_cli.h"
#include "sciyon_ipmc.h"

extern sciyon_vlanif_t sciyon_g_vlanif_pool[SCIYON_VLANIF_MAX_NUM];
extern uint8 sciyon_g_vlanif_num;

extern sciyon_ipmc_t  sciyon_g_ipmc_pool[SCIYON_IPMC_MAX_NUM];
extern uint16 sciyon_g_ipmc_num;

CTC_CLI(sciyon_cli_ipmc_display_entry_config,
        sciyon_cli_ipmc_display_entry_cmd,
        "display ipmc",
        "display",
        "ipmc")
{
    int i;
    uint8 *ip=NULL;
    char ipmcstr[20];

    ctc_cli_out("ID        GROUP ADDRESS      AGING\n");
    ctc_cli_out("-------------------------------------------------------\n");
    for(i = 0; i < sciyon_g_ipmc_num; i++)
    {
        ip = (uint8 *)&sciyon_g_ipmc_pool[i].group_address;
        sal_sprintf(ipmcstr, "%d", sciyon_g_ipmc_pool[i].group_id);
        ctc_cli_out("%-10s", ipmcstr);
        sal_sprintf(ipmcstr, "%d.%d.%d.%d", ip[3], ip[2], ip[1], ip[0]);
        ctc_cli_out("%-19s", ipmcstr);
        sal_sprintf(ipmcstr, "%d", sciyon_g_ipmc_pool[i].aging_timer);
        ctc_cli_out("%-5s\n", ipmcstr);
    }
    ctc_cli_out("-------------------------------------------------------\n");
    ctc_cli_out("used: %d/%d\n", sciyon_g_ipmc_num, SCIYON_IPMC_MAX_NUM);
    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_ipmc_route_enable_config,
        sciyon_cli_ipmc_route_enable_cmd,
        "multicast routing-enable",
        "multicast module", 
        "enable")
{
    int i;
    ctc_l3if_property_t l3if_prop;
    ctc_ipmc_group_info_t ipmc_group_info;
    uint16 l3if_id;

    for(i = 0; i < sciyon_g_vlanif_num; i++)
    {
        l3if_prop = CTC_L3IF_PROP_IPV4_MCAST;
        l3if_id = sciyon_g_vlanif_pool[i].vlan_id;
        ctc_l3if_set_property(l3if_id, l3if_prop, TRUE);
    }

    /* 添加组播默认路由 */
    sal_memset(&ipmc_group_info, 0, sizeof(ctc_ipmc_group_info_t));
    ipmc_group_info.ip_version = CTC_IP_VER_4;
    ipmc_group_info.address.ipv4.vrfid = 0;
    ipmc_group_info.flag |= CTC_IPMC_FLAG_REDIRECT_TOCPU;
    ctc_ipmc_add_group(&ipmc_group_info);

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_ipmc_route_disable_config,
        sciyon_cli_ipmc_route_disable_cmd,
        "multicast routing-disable",
        "multicast module", 
        "enable")
{
    int i;
    ctc_l3if_property_t l3if_prop;
    uint16 l3if_id;

    for(i = 0; i < sciyon_g_vlanif_num; i++)
    {
        l3if_prop = CTC_L3IF_PROP_IPV4_MCAST;
        l3if_id = sciyon_g_vlanif_pool[i].vlan_id;
        ctc_l3if_set_property(l3if_id, l3if_prop, FALSE);
    }

    return CLI_SUCCESS;
}

CTC_CLI(sciyon_cli_ipmc_deploy_config,
        sciyon_cli_ipmc_deploy_cmd,
        "ipmc deploy",
        "ipmc", 
        "deploy")
{
    sciyon_hard_ipmc_pool_clear();
    sciyon_ipmc_pool_deploy();

    return CLI_SUCCESS;
}

int32 sciyon_cli_ipmc_init(void)
{
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_ipmc_route_enable_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_ipmc_route_disable_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_ipmc_display_entry_cmd);
    install_element(SCIYON_SYSTEM_MODE, &sciyon_cli_ipmc_deploy_cmd);
    return CLI_SUCCESS;
}