/*************************************************************************************
  Copyright (C), 2016-2021, Nanjing SCIYON Automation Group Co., Ltd.
  FileName: sciyon_cli.h
  Author: yinsj             Version: 1.0.0000          Data: 2021-04-02 
  
  Description   : CLI初始化头文件
  Version       : ver 1.0.0000

  Function List : 

  History       :
  <author>      <time>      <version>    <description>
  yinsj         2021-4-2    1.0.0000     初次建立
*************************************************************************************/
#ifndef _SCIYON_CLI_H
#define _SCIYON_CLI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sal_types.h"
#include "ctc_cli.h"

#define SCIYON_USER_MODE            20
#define SCIYON_SYSTEM_MODE          21
#define SCIYON_INTERFACE_MODE       22
#define SCIYON_VLAN_MODE            23
#define SCIYON_LOGIN_MODE           24
#define SCIYON_PASSWD_MODE          25
#define SCIYON_MAX_PROMPT_LEN       100 /* 最大提示符长度 */
#define SCIYON_PASSWD_LEN           9
#define SCIYON_PASSWD_INPUT_LEN     80

#define VLAN_MODULE_STR "vlan module"
#define DISPLAY_MODULE_STR "display module"
#define PORT_MODULE_STR "port module"
#define SAVE_MODULE_STR "save module"
#define UNDO_MODULE_STR "save module"

extern ctc_cmd_node_t interface_node;
extern ctc_cmd_node_t vlan_node;
extern ctc_cmd_node_t system_node;
extern ctc_cmd_node_t user_node;

extern uint32 sciyon_g_current_panel_port;
extern uint32 sciyon_g_current_global_port;
extern uint32 sciyon_g_current_vlan_id;

int32 sciyon_cli_init(void);

#ifdef __cplusplus
}
#endif

#endif /* _SCIYON_CLI_H */