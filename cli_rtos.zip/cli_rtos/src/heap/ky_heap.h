
#ifndef _KY_HEAP_H
#define _KY_HEAP_H

#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef signed char        int8;    /**< 8-bit  signed integer   */
typedef short int          int16;   /**< 16-bit signed integer   */
typedef signed int         int32;   /**< 32-bit signed integer   */
typedef long int           int64;   /**< 64-bit signed integer   */
typedef unsigned char      uint8;   /**< 8-bit  unsigned integer */
typedef unsigned short int uint16;  /**< 16-bit unsigned integer */
typedef unsigned int       uint32;  /**< 32-bit unsigned integer */
typedef unsigned long int  uint64;  /**< 64-bit unsigned integer */
typedef float              float32; /**< 32-bit signed float     */
typedef double             float64; /**< 64-bit signed float     */

typedef signed char        int8_t;    /**< 8-bit  signed integer   */
typedef short int          int16_t;   /**< 16-bit signed integer   */
typedef signed int         int32_t;   /**< 32-bit signed integer   */
typedef unsigned char      uint8_t;   /**< 8-bit  unsigned integer */
typedef unsigned short int uint16_t;  /**< 16-bit unsigned integer */
typedef unsigned int       uint32_t;  /**< 32-bit unsigned integer */
typedef float              float32_t; /**< 32-bit signed float     */
typedef double             float64_t; /**< 64-bit signed float     */

void *ky_port_malloc(size_t para_wanted_size);
void *ky_port_realloc(void *para_ptr, size_t para_size);
void ky_port_free(void *para_pv);
size_t ky_port_get_free_heap_size(void);
size_t ky_port_get_minimum_ever_free_heap_size(void);

#ifdef __cplusplus
}
#endif

#endif /* _KY_HEAP_H */
