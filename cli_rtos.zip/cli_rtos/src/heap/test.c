
#include "ky_heap.h"
#include <stdio.h>

#define SHOW_FREE_HEAP_SIZE() do{\
                                    free_size = ky_port_get_free_heap_size();\
                                    printf("free heap: %d\n", free_size);\
                                } while(0)

int main(int argc, char **argv)
{
    void *buff = NULL;
    void *buff1 = NULL;
    void *buff2 = NULL;
    void *buff3 = NULL;
    void *buff4 = NULL;
    int free_size = 0;
    int minimum_size = 0;

    buff = ky_port_malloc(0);
    printf("malloc %d\n", 0);
    SHOW_FREE_HEAP_SIZE();
    
    buff1 = ky_port_malloc(100);
    printf("malloc %d\n", 100);
    SHOW_FREE_HEAP_SIZE();

    buff2 = ky_port_malloc(100);
    printf("malloc %d\n", 100);
    SHOW_FREE_HEAP_SIZE();

    buff3 = ky_port_malloc(100);
    printf("malloc %d\n", 100);
    SHOW_FREE_HEAP_SIZE();

    ky_port_free(buff2);
    printf("free buff2\n");
    SHOW_FREE_HEAP_SIZE();

    buff4 = ky_port_malloc(200);
    printf("malloc %d\n", 200);
    SHOW_FREE_HEAP_SIZE();

    minimum_size = ky_port_get_minimum_ever_free_heap_size();
    printf("minimum size: %d\n", minimum_size);

    ky_port_free(buff3);
    printf("free buff3\n");
    SHOW_FREE_HEAP_SIZE();

    ky_port_free(buff1);
    printf("free buff1\n");
    SHOW_FREE_HEAP_SIZE();

    ky_port_realloc(buff4, 200);
    printf("realloc buff4 100\n");
    SHOW_FREE_HEAP_SIZE();
}
