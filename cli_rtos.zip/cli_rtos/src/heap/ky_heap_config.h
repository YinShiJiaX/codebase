
#ifndef _KY_HEAP_CONFIG_H
#define _KY_HEAP_CONFIG_H
	
#ifdef __cplusplus
	extern "C" {
#endif

#define KY_CONFIG_TOTAL_HEAP_SIZE  (8 * 1024)
#define KY_CONFIG_BYTE_ALIGNMENT 8

#if KY_CONFIG_BYTE_ALIGNMENT == 8
    #define KY_BYTE_ALIGNMENT_MASK ( 0x0007 )
#endif

#define KY_BITS_PER_BYTE ( ( size_t )8 )

#define KY_COVERAGE_TEST_MARKER()
	
#ifdef __cplusplus
	}
#endif
	
#endif /* _KY_HEAP_H */

