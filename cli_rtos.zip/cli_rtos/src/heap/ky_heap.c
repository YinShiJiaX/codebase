/**
 @file ky_heap.c

 @date 2022-3-19

 copied from FreeRTOS->heap_4.c
*/

#include "ky_heap.h"
#include "ky_heap_config.h"

/* Block sizes must not get too small. */
#define KY_HEAP_MINIMUM_BLOCK_SIZE ( (size_t)( ky_heap_struct_size << 1) )

/* Allocate the memory for the heap. */
static char ky_heap[KY_CONFIG_TOTAL_HEAP_SIZE];

/* Define the linked list structure.  This is used to link free blocks in order
of their memory address. */
struct a_block_link_s {
    struct a_block_link_s *next_free_block;
    size_t block_size;
};
typedef struct a_block_link_s block_link_t;

/*
 * Inserts a block of memory that is being freed into the correct position in
 * the list of free memory blocks.  The block being freed will be merged with
 * the block in front it and/or the block behind it if the memory blocks are
 * adjacent to each other.
 */
static void ky_insert_block_into_free_list(block_link_t *para_block_to_insert);

/*
 * Called automatically to setup the required heap structures the first time
 * ky_port_malloc() is called.
 */
static void ky_heap_init( void );

/* The size of the structure placed at the beginning of each allocated memory
block must by correctly byte aligned. */
static const size_t ky_heap_struct_size	= ( sizeof( block_link_t ) + ( ( size_t ) ( KY_CONFIG_BYTE_ALIGNMENT - 1 ) ) ) & ~( ( size_t ) KY_BYTE_ALIGNMENT_MASK );

/* Create a couple of list links to mark the start and end of the list. */
static block_link_t ky_start, *ky_end = NULL;

/* Keeps track of the number of free bytes remaining, but says nothing about
fragmentation. */
static size_t ky_free_bytes_remaining = 0U;
static size_t ky_minimum_ever_free_bytes_remaining = 0U;

/* Gets set to the top bit of an size_t type.  When this bit in the block_size
member of an block_link_t structure is set then the block belongs to the
application.  When the bit is free the block is still part of the free heap
space. */
static size_t ky_block_allocated_bit = 0;

void *ky_port_malloc(size_t para_wanted_size)
{
    block_link_t *lc_block, *lc_previous_block, *lc_new_block_link;
    void *lc_return = NULL;

	/* If this is the first call to malloc then the heap will require
	initialisation to setup the list of free blocks. */
    if(ky_end == NULL)
    {
        ky_heap_init();
    }
    else
    {
        KY_COVERAGE_TEST_MARKER();
    }

	/* Check the requested block size is not so large that the top bit is
	set.  The top bit of the block size member of the block_link_t structure
	is used to determine who owns the block - the application or the
	kernel, so it must be free. */
    if(  0 == (para_wanted_size & ky_block_allocated_bit) )
    {
		/* The wanted size is increased so it can contain a block_link_t
		structure in addition to the requested amount of bytes. */
        if( para_wanted_size > 0 )
        {
            para_wanted_size += ky_heap_struct_size;

			/* Ensure that blocks are always aligned to the required number
			of bytes. */
            if( 0x00 != ( para_wanted_size & KY_BYTE_ALIGNMENT_MASK ) )
            {
                /* Byte alignment required. */
                para_wanted_size += ( KY_CONFIG_BYTE_ALIGNMENT - ( para_wanted_size & KY_BYTE_ALIGNMENT_MASK ) );
            }
            else
            {
                KY_COVERAGE_TEST_MARKER();
            }
        }
        else
        {
            KY_COVERAGE_TEST_MARKER();
        }

		if( ( para_wanted_size > 0 ) && ( para_wanted_size <= ky_free_bytes_remaining ) )
		{
			/* Traverse the list from the start (lowest address) block until
			one of adequate size is found. */
			lc_previous_block = &ky_start;
			lc_block = ky_start.next_free_block;
			while( ( lc_block->block_size < para_wanted_size ) && ( lc_block->next_free_block != NULL ) )
			{
				lc_previous_block = lc_block;
				lc_block = lc_block->next_free_block;
			}
		
			/* If the end marker was reached then a block of adequate size
			was not found. */
			if( lc_block != ky_end )
			{
				/* Return the memory space pointed to - jumping over the
				block_link_t structure at its start. */
				lc_return = ( void * ) ( ( ( uint8_t * ) lc_previous_block->next_free_block ) + ky_heap_struct_size );
		
				/* This block is being returned for use so must be taken out
				of the list of free blocks. */
				lc_previous_block->next_free_block = lc_block->next_free_block;
		
				/* If the block is larger than required it can be split into
				two. */
				if( ( lc_block->block_size - para_wanted_size ) > KY_HEAP_MINIMUM_BLOCK_SIZE )
				{
					/* This block is to be split into two.	Create a new
					block following the number of bytes requested. The void
					cast is used to prevent byte alignment warnings from the
					compiler. */
					lc_new_block_link = ( void * ) ( ( ( uint8_t * ) lc_block ) + para_wanted_size );
		
					/* Calculate the sizes of two blocks split from the
					single block. */
					lc_new_block_link->block_size = lc_block->block_size - para_wanted_size;
					lc_block->block_size = para_wanted_size;
		
					/* Insert the new block into the list of free blocks. */
					ky_insert_block_into_free_list( lc_new_block_link );
				}
				else
				{
					KY_COVERAGE_TEST_MARKER();
				}
		
				ky_free_bytes_remaining -= lc_block->block_size;
		
				if( ky_free_bytes_remaining < ky_minimum_ever_free_bytes_remaining )
				{
					ky_minimum_ever_free_bytes_remaining = ky_free_bytes_remaining;
				}
				else
				{
					KY_COVERAGE_TEST_MARKER();
				}
		
				/* The block is being returned - it is allocated and owned
				by the application and has no "next" block. */
				lc_block->block_size |= ky_block_allocated_bit;
				lc_block->next_free_block = NULL;
			}
			else
			{
				KY_COVERAGE_TEST_MARKER();
			}
		}
		else
		{
			KY_COVERAGE_TEST_MARKER();
		}
    }
    else
    {
        KY_COVERAGE_TEST_MARKER();
    }

    return lc_return;
}

void ky_port_free(void *para_pv)
{
    uint8_t *puc = (uint8 *)para_pv;
    block_link_t *lc_link;

    if( NULL != para_pv )
    {
		/* The memory being freed will have an block_link_t structure immediately
		before it. */
        puc -= ky_heap_struct_size;

		/* This casting is to keep the compiler from issuing warnings. */
        lc_link = ( void *)puc;

		/* Check the block is actually allocated. */
		if( ( lc_link->block_size & ky_block_allocated_bit ) != 0 )
		{
			if(  NULL == lc_link->next_free_block )
			{
				/* The block is being returned to the heap - it is no longer
				allocated. */
				lc_link->block_size &= ~ky_block_allocated_bit;
				
				/* Add this block to the list of free blocks. */
				ky_free_bytes_remaining += lc_link->block_size;
				ky_insert_block_into_free_list( ( ( block_link_t * ) lc_link ) );
			}
			else
			{
				KY_COVERAGE_TEST_MARKER();
			}
		}
		else
		{
			KY_COVERAGE_TEST_MARKER();
		}
    }
}

size_t ky_port_get_free_heap_size(void)
{
    return ky_free_bytes_remaining;
}

size_t ky_port_get_minimum_ever_free_heap_size(void)
{
    return ky_minimum_ever_free_bytes_remaining;
}

static void ky_heap_init(void)
{
    block_link_t *lc_first_free_block;
	uint8_t *lc_aligned_heap;
	size_t lc_address;
	size_t lc_total_heap_size = KY_CONFIG_TOTAL_HEAP_SIZE;
	
	/* Ensure the heap starts on a correctly aligned boundary. */
	lc_address = ( size_t ) ky_heap;

	if( ( lc_address & KY_BYTE_ALIGNMENT_MASK ) != 0 )
	{
		lc_address += ( KY_CONFIG_BYTE_ALIGNMENT - 1 );
		lc_address &= ~( ( size_t ) KY_BYTE_ALIGNMENT_MASK );
		lc_total_heap_size -= lc_address - ( size_t ) ky_heap;
	}

	lc_aligned_heap = ( uint8_t * ) lc_address;

	/* ky_start is used to hold a pointer to the first item in the list of free
	blocks.  The void cast is used to prevent compiler warnings. */
	ky_start.next_free_block = ( void * ) lc_aligned_heap;
	ky_start.block_size = ( size_t ) 0;

	/* ky_end is used to mark the end of the list of free blocks and is inserted
	at the end of the heap space. */
	lc_address = ( ( size_t ) lc_aligned_heap ) + lc_total_heap_size;
	lc_address -= ky_heap_struct_size;
	lc_address &= ~( ( size_t ) KY_BYTE_ALIGNMENT_MASK );
	ky_end = ( void * ) lc_address;
	ky_end->block_size = 0;
	ky_end->next_free_block = NULL;

	/* To start with there is a single free block that is sized to take up the
	entire heap space, minus the space taken by ky_end. */
	lc_first_free_block = ( void * ) lc_aligned_heap;
	lc_first_free_block->block_size = lc_address - ( size_t ) lc_first_free_block;
	lc_first_free_block->next_free_block = ky_end;

	/* Only one block exists - and it covers the entire usable heap space. */
	ky_minimum_ever_free_bytes_remaining = lc_first_free_block->block_size;
	ky_free_bytes_remaining = lc_first_free_block->block_size;

	/* Work out the position of the top bit in a size_t variable. */
	ky_block_allocated_bit = ( ( size_t ) 1 ) << ( ( sizeof( size_t ) * KY_BITS_PER_BYTE ) - 1 );

}

static void ky_insert_block_into_free_list( block_link_t *para_block_to_insert )
{
    block_link_t *lc_iterator;
    uint8_t *puc;

	/* Iterate through the list until a block is found that has a higher address
	than the block being inserted. */
	for( lc_iterator = &ky_start; lc_iterator->next_free_block < para_block_to_insert; lc_iterator = lc_iterator->next_free_block )
	{
		/* Nothing to do here, just iterate to the right position. */
	}

	/* Do the block being inserted, and the block it is being inserted after
	make a contiguous block of memory? */
	puc = ( uint8_t * ) lc_iterator;
	if( ( puc + lc_iterator->block_size ) == ( uint8_t * ) para_block_to_insert )
	{
		lc_iterator->block_size += para_block_to_insert->block_size;
		para_block_to_insert = lc_iterator;
	}
	else
	{
		KY_COVERAGE_TEST_MARKER();
	}

	/* Do the block being inserted, and the block it is being inserted before
	make a contiguous block of memory? */
	puc = ( uint8_t * ) para_block_to_insert;
	if( ( puc + para_block_to_insert->block_size ) == ( uint8_t * ) lc_iterator->next_free_block )
	{
		if( lc_iterator->next_free_block != ky_end )
		{
			/* Form one big block from the two blocks. */
			para_block_to_insert->block_size += lc_iterator->next_free_block->block_size;
			para_block_to_insert->next_free_block = lc_iterator->next_free_block->next_free_block;
		}
		else
		{
			para_block_to_insert->next_free_block = ky_end;
		}
	}
	else
	{
		para_block_to_insert->next_free_block = lc_iterator->next_free_block;
	}

	/* If the block being inserted plugged a gab, so was merged with the block
	before and the block after, then it's next_free_block pointer will have
	already been set, and should not be set here as that would make it point
	to itself. */
	if( lc_iterator != para_block_to_insert )
	{
		lc_iterator->next_free_block = para_block_to_insert;
	}
	else
	{
		KY_COVERAGE_TEST_MARKER();
	}
}

void *ky_port_realloc(void *para_ptr, size_t para_size)
{
    void *lc_ptr = NULL;
    ky_port_free(para_ptr);
    lc_ptr = ky_port_malloc(para_size);

    return lc_ptr;
}

