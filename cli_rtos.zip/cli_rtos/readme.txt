
# description: 
a cli with heap management

# usage: 
see example/main.c