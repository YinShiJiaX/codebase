/**
 @file ctc_cli.h

 @date 2010-7-9

 @version v2.0

  The file defines Macro, stored data structure for ctc cli
*/
#ifndef _CTC_CLI_H
#define _CTC_CLI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sal.h"
#include "sal_types.h"

#include "ctc_vti.h"
#include "ctc_cmd.h"
#include "ctc_regex.h"

/* CLI modes.  */

#define EXEC_MODE 0
#define CTC_SDK_MODE 1
#define CTC_CMODEL_MODE 2
#define CTC_SDK_OAM_CHAN_MODE 3
#define CTC_DEBUG_MODE 4
#define CTC_DBG_TOOL_MODE 5
#define CTC_CTCCLI_MODE 6
#define CTC_INTERNAL_MODE 7
#define CTC_APP_MODE 8
#define CTC_DKITS_MODE 9
#define CTC_STRESS_MODE 10

/* Return value.  */
#define CLI_SUCCESS           0
#define CLI_ERROR             1
#define CLI_AUTH_REQUIRED     2
#define CLI_EOL               3

/* Max length of each token.  */
#define MAX_TOKEN_LENGTH   256

/* Used for shield system API other than show command */
#undef SDK_INTERNAL_CLIS

/* Used for shield system API in show command */
#define SDK_INTERNAL_CLI_SHOW

#define UINT64_STR_LEN      21

#define CTC_MAX_UINT16_VALUE 0xFFFF
#define CTC_MAX_UINT32_VALUE 0xFFFFFFFF
#define CTC_MAX_UINT8_VALUE 0xFF

#define MAX_FILE_NAME_SIZE      256

#define MAX_CLI_STRING_LEN 1000

struct ctc_l2_write_info_para_s
{
    char file[MAX_FILE_NAME_SIZE];
    void* pdata;
};
typedef struct ctc_l2_write_info_para_s ctc_l2_write_info_para_t;

typedef int (* CTC_CLI_OUT_FUNC) (const char* str, ...);
int ctc_cli_out(const char* fmt, ...);


#ifdef HAVE_ISO_MACRO_VARARGS
#define CTC_CLI(func_name, cli_name, cmd_str, ...)  \
    char* cli_name ## _help[] = {__VA_ARGS__, NULL}; \
    DEFUN(func_name, cli_name, cmd_str, cli_name ## _help)
#else
#define CTC_CLI(func_name, cli_name, cmd_str, ARGS...) \
    char* cli_name ## _help[] = {ARGS, NULL}; \
    DEFUN(func_name, cli_name, cmd_str, cli_name ## _help)
#endif

extern uint8 g_cli_parser_param_en;
extern uint32
ctc_cmd_get_value(int32* ret, char* name, char* str, uint32 min, uint32 max, uint8 type);
extern int32
ctc_cmd_str2int(char* str, int32* ret);
extern uint32
ctc_cmd_str2uint(char* str, int32* ret);
extern uint64
ctc_cmd_str2uint64(char* str, int32* ret);
extern void
    ctc_uint64_to_str(uint64 src, char dest[UINT64_STR_LEN]);
extern int32
ctc_cmd_str2nint (char *str, int32 *ret, uint32 *val);


extern int32
ctc_cmd_judge_is_num(char* str);

extern char*
ctc_cli_get_debug_desc(unsigned char level);

enum cmd_token_type_s
{
    cmd_token_paren_open,
    cmd_token_paren_close,
    cmd_token_cbrace_open,
    cmd_token_cbrace_close,
    cmd_token_brace_open,
    cmd_token_brace_close,
    cmd_token_separator,
    cmd_token_keyword,
    cmd_token_var,
    cmd_token_unknown
};
typedef enum cmd_token_type_s cmd_token_type;

/* APIs, user shall also call  CTC_CLI(), install_element() */
extern ctc_vti_t* g_ctc_vti;

extern int
ctc_vti_read(int8* buf, uint32 buf_size,uint32 mode);
extern int
ctc_vti_read_cmd(ctc_vti_t* vty, const int8* szbuf, const uint32 buf_len);
extern void
ctc_cmd_init(int terminal);
extern void ctc_cli_register_print_fun(CTC_CLI_OUT_FUNC func);
extern unsigned char
ctc_cli_get_prefix_item(char** argv, unsigned char argc, char* prefix, unsigned char prefix_len);
extern int
ctc_vti_command(ctc_vti_t* vti, char* buf);

extern void
set_terminal_raw_mode(uint32 mode);

extern void
restore_terminal_mode(uint32 mode);

extern void
ctc_cli_enable_cmd_debug(int enable);

extern void
ctc_cli_enable_arg_debug(int enable);

#ifdef __cplusplus
}
#endif

#endif /* _CTC_CLI_H */

